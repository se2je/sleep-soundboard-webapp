import {makeAutoObservable} from 'mobx';
import type {RootStore} from './RootStore';
import {fetchJson} from '@/api/fetchJson.ts'; // предполагается, что ты добавишь эту утилиту
import i18n from '@/i18n';

interface UserDataResponse {
    FUN: number;
    MTKN: number;
    checkin_streak: number;
    max_checkin_streak: number;
    karma?: number | null;
    keys?: number | null;
    tickets?: number | null;


}

export class UserDataStore {
    currency = {tokens: 450000, gameCoins: 9200000};
    comboStreak = 0;
    maxComboStreak = 0;
    isLoading = false;
    karma = 0;
    keys = 0;
    tickets = 30;

    constructor(private root: RootStore) {
        makeAutoObservable(this);
    }

    async fetchUserData(userId: string) {
        this.isLoading = true;
        try {
            const data = await fetchJson<UserDataResponse>(
                `https://api.mysterytoken.org:8443/user/${userId}`
            );

            this.currency = {
                tokens: data.MTKN ?? 0,
                gameCoins: data.FUN ?? 0,
            };
            this.comboStreak = data.checkin_streak ?? 0;
            this.maxComboStreak = data.max_checkin_streak ?? 0;
            this.karma = data.karma ?? 0;
            this.keys = data.keys ?? 0;
            this.tickets = data.tickets ?? 0;

        } catch (error) {
            console.error('Ошибка получения данных пользователя:', error);
        } finally {
            this.isLoading = false;
        }
    }

    async checkIn(userId: string | null) {
        try {
            const data = await fetchJson<UserDataResponse>(
                `https://api.mysterytoken.org:8443/checkin/${userId}`,
                {method: 'POST'}
            );

            this.currency = {
                tokens: data.MTKN ?? 0,
                gameCoins: data.FUN ?? 0,
            };
            this.comboStreak = data.checkin_streak ?? 0;
            this.maxComboStreak = data.max_checkin_streak ?? 0;

            this.root.checkInStore.setIsCheckedIn();
        } catch (error) {
            console.error('Ошибка чек-ина:', error);
            this.root.uiStore.setErrorMessage(i18n.t('errors.checkIn'));
            this.root.checkInStore.setIsCheckedIn();
        }
    }

    async spendTicket(): Promise<boolean> {
        if (this.tickets <= 0) return false;

        try {
            await fetchJson(`https://api.mysterytoken.org:8443/user/spend-ticket`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({amount: 1}) // или userId, если нужно
            });
            this.tickets -= 1;
            return true;
        } catch (err) {
            console.error('Ошибка списания билета:', err);
            return false;
        }
    }

}


