import { makeAutoObservable } from 'mobx';
import i18n from '@/i18n';
import type { RootStore } from './RootStore';

export class UiStore {
    language: string = localStorage.getItem('i18nextLng') || 'en';
    errorMessage: string | null = null;
    errorTimeoutId: NodeJS.Timeout | null = null;

    constructor(private root: RootStore) {
        makeAutoObservable(this);
        i18n.changeLanguage(this.language);
    }

    setLanguage(lang: string) {
        this.language = lang;
        localStorage.setItem('i18nextLng', lang);
        i18n.changeLanguage(lang);
    }

    setErrorMessage(message: string) {
        if (this.errorTimeoutId) {
            clearTimeout(this.errorTimeoutId);
            this.errorTimeoutId = null;
        }

        this.errorMessage = message;

        this.errorTimeoutId = setTimeout(() => {
            this.clearErrorMessage();
        }, 3000);
    }

    clearErrorMessage() {
        this.errorMessage = null;
    }
}
