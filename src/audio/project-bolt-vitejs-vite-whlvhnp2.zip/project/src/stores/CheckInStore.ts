import { makeAutoObservable } from 'mobx';
import type { RootStore } from './RootStore';

export interface CheckInReward {
    tokens: number;
    gameCoins: number;
}

const DAILY_REWARDS: CheckInReward[] = [
    { tokens: 5, gameCoins: 200 },   // Day 1
    { tokens: 6, gameCoins: 250 },   // Day 2
    { tokens: 7, gameCoins: 300 },   // Day 3
    { tokens: 8, gameCoins: 350 },   // Day 4
    { tokens: 9, gameCoins: 400 },   // Day 5
    { tokens: 10, gameCoins: 450 },  // Day 6
    { tokens: 11, gameCoins: 500 },  // Day 7
];

export class CheckInStore {
    isCheckedIn = false;
    lastCheckIn: string | null = null;
    rewards = DAILY_REWARDS;

    constructor(private root: RootStore) {
        makeAutoObservable(this);

        // dummy read to avoid TS6138
        void this.root
    }

    setIsCheckedIn() {
        this.isCheckedIn = true;
    }

    setLastCheckIn(date: string) {
        this.lastCheckIn = date;
    }

    resetCheckIn() {
        this.isCheckedIn = false;
        this.lastCheckIn = null;
    }
}
