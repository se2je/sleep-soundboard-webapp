import { observer } from "mobx-react-lite";
import { rootStore } from '@stores/RootStore';
import { motion, AnimatePresence } from 'framer-motion';
import s from './ErrorTooltip.module.scss';

const ErrorTooltip = observer(() => {
    return (
        <AnimatePresence>
            {rootStore.errorMessage && (
                <motion.div
                    className={s.tooltip}
                    initial={{ opacity: 0, y: 20, x: "-50%" }}
                    animate={{ opacity: 1, y: 0, x: "-50%" }}
                    exit={{ opacity: 0, y: -20, x: "-50%" }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                    {rootStore.errorMessage}
                </motion.div>
            )}
        </AnimatePresence>
    );
});

export default ErrorTooltip;