import { motion, AnimatePresence } from 'framer-motion';
import { X } from '@phosphor-icons/react';
import { useTranslation } from 'react-i18next';
import { createPortal } from 'react-dom';
import styles from './StreakModal.module.scss';

const REWARDS = [
  { day: 1, coins: 200, tokens: 5 },
  { day: 2, coins: 250, tokens: 6 },
  { day: 3, coins: 300, tokens: 7 },
  { day: 4, coins: 350, tokens: 8 },
  { day: 5, coins: 400, tokens: 9 },
  { day: 6, coins: 450, tokens: 10 },
  { day: 7, coins: 500, tokens: 11 },
];

interface StreakModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const StreakModal = ({ isOpen, onClose }: StreakModalProps) => {
  const { t } = useTranslation();

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className={styles.overlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className={styles.modal}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={e => e.stopPropagation()}
          >
            <button
              className={styles.closeButton}
              onClick={onClose}
            >
              <X size={24} weight="bold" />
            </button>

            <h2 className={styles.title}>{t('streakInfo.title')}</h2>

            <div className={styles.content}>
              <div className={styles.rewardList}>
                {REWARDS.map(({ day, coins, tokens }) => (
                  <div key={day} className={styles.rewardItem}>
                    <span className={styles.day}>
                      {t('streakInfo.day', { day })}
                    </span>
                    <div className={styles.rewards}>
                      <span className={styles.reward}>
                        <span>🪙</span> {coins}
                      </span>
                      <span className={styles.reward}>
                        <span>💎</span> {tokens}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <p className={styles.note}>
                {t('streakInfo.note')}
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body
  );
};

export default StreakModal;