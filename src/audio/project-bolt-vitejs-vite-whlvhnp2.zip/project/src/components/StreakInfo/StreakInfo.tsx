import { useState } from 'react';
import StreakButton from './StreakButton';
import StreakModal from './StreakModal';

const StreakInfo = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <StreakButton onClick={() => setIsOpen(true)} />
      <StreakModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};

export default StreakInfo;