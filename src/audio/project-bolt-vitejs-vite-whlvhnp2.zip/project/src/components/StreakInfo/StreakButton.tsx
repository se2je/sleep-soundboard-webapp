import { motion } from 'framer-motion';
import { Question } from '@phosphor-icons/react';
import styles from './StreakButton.module.scss';

interface StreakButtonProps {
  onClick: () => void;
}

const StreakButton = ({ onClick }: StreakButtonProps) => {
  return (
    <motion.button
      className={styles.infoButton}
      onClick={onClick}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      <Question size={16} weight="bold" />
    </motion.button>
  );
};

export default StreakButton;