import {motion} from 'framer-motion';
import {useTranslation} from 'react-i18next';
import {Wrench} from '@phosphor-icons/react';
import styles from './DevelopmentInfo.module.scss';

const DevelopmentInfo = () => {
    const {t} = useTranslation();

    return (
        <motion.div
            className={styles.infoSection}
            initial={{opacity: 0, y: 20}}
            animate={{opacity: 1, y: 0}}
        >
            <div className={styles.title}>
                <Wrench size={24} weight="duotone"/>
                {t('lobby.developmentInfo.title')}
            </div>
            <span className={styles.version}>
        {t('lobby.developmentInfo.version')}
      </span>
            <p className={styles.description}>
                {t('lobby.developmentInfo.description')}
            </p>
        </motion.div>
    );
};

export default DevelopmentInfo;