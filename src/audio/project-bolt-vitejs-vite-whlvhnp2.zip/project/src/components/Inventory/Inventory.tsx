import {useState} from 'react';
import {motion} from 'framer-motion';
import {Key, Ticket} from '@phosphor-icons/react';
import InfoPopup from '../InfoPopup/InfoPopup';
import styles from './Inventory.module.scss';
import CASE from '@media/A2.png';
import CASE2 from '@media/B.png';
import CASE3 from '@media/C.png';
import CASE4 from '@media/D.png'
import {rootStore} from "@stores/RootStore.ts";
import {useTranslation} from "react-i18next";


interface InventoryItem {
    id: string;
    name: string;
    description: string;
    image: string;
    rarity: 'common' | 'rare' | 'epic' | 'legendary';
    type: 'treasure' | 'nft' | 'item';
    actions: string[];
}

const mockItems: InventoryItem[] = [
    {
        id: '1',
        name: 'Case',
        description: 'A mysterious box that contains random NFT dog. Requires a key to open.',
        image: CASE,
        rarity: 'common',
        type: 'treasure',
        actions: ['Open', 'Trade']
    },

    {
        id: '3',
        name: 'Cyber Case',
        description: 'A rare cybernetic dog NFT with enhanced farming capabilities.',
        image: CASE2,
        rarity: 'rare',
        type: 'nft',
        actions: ['View', 'Trade', 'Farm']
    },
    {
        id: '4',
        name: 'Mystery Case',
        description: 'A rare cybernetic dog NFT with enhanced farming capabilities.',
        image: CASE3,
        rarity: 'epic',
        type: 'nft',
        actions: ['View', 'Trade', 'Farm']
    },
    {
        id: '5',
        name: 'Jesus Case',
        description: 'A rare cybernetic dog NFT with enhanced farming capabilities.',
        image: CASE4,
        rarity: 'legendary',
        type: 'nft',
        actions: ['View', 'Trade', 'Farm']
    },
    {
        id: '2',
        name: 'Case',
        description: 'A luxurious box with increased chances of rare NFT dogs.',
        image: CASE,
        rarity: 'common',
        type: 'treasure',
        actions: ['Open', 'Trade']
    },
];

const Inventory = () => {
    const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
    const {t} = useTranslation();


    return (
        <div className={styles.inventory}>
            <div className={styles.header}>
                <h2 className={styles.title}>{t('tabs.inventory')}</h2>
                <div className={styles.currencies}>
                    <div className={styles.currency}>
                        <Key size={24} weight="duotone" className={styles.icon}/>
                        <span className={styles.value}>{rootStore.userDataStore.keys} {t('user.keys')}</span>
                    </div>
                    <div className={styles.currency}>
                        <Ticket size={24} weight="duotone" className={styles.icon}/>
                        <span className={styles.value}>{rootStore.userDataStore.tickets} {t('user.tickets')}</span>
                    </div>
                </div>
            </div>

            <div className={styles.grid}>
                {mockItems.map((item) => (
                    <motion.div
                        key={item.id}
                        className={styles.item}
                        onClick={() => setSelectedItem(item)}
                        whileHover={{scale: 1.05}}
                        whileTap={{scale: 0.95}}
                    >
                        <img src={item.image} alt={item.name} className={styles.itemImage}/>
                        <div className={styles.itemName}>{item.name}</div>
                        <div className={`${styles.itemRarity} ${styles[item.rarity]}`}>
                            {item.rarity.charAt(0).toUpperCase() + item.rarity.slice(1)}
                        </div>
                    </motion.div>
                ))}
            </div>

            <InfoPopup
                isOpen={!!selectedItem}
                onClose={() => setSelectedItem(null)}
                title="Item Details"
            >
                {selectedItem && (
                    <div className={styles.itemDetails}>
                        <div className={styles.itemHeader}>
                            <img src={selectedItem.image} alt={selectedItem.name} className={styles.itemImage}/>
                            <div className={styles.itemInfo}>
                                <h3 className={styles.itemName}>{selectedItem.name}</h3>
                                <div className={`${styles.itemRarity} ${styles[selectedItem.rarity]}`}>
                                    {selectedItem.rarity.charAt(0).toUpperCase() + selectedItem.rarity.slice(1)}
                                </div>
                            </div>
                        </div>
                        <p className={styles.itemDescription}>{selectedItem.description}</p>
                        <div className={styles.itemActions}>
                            {selectedItem.actions.map((action) => (
                                <motion.button
                                    key={action}
                                    className={styles.actionButton}
                                    whileHover={{scale: 1.05}}
                                    whileTap={{scale: 0.95}}
                                >
                                    {action}
                                </motion.button>
                            ))}
                        </div>
                    </div>
                )}
            </InfoPopup>
        </div>
    );
};

export default Inventory;