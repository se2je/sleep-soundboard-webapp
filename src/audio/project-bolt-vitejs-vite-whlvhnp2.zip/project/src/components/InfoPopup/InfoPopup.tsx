import { motion, AnimatePresence } from 'framer-motion';
import { X } from '@phosphor-icons/react';
import { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import styles from './InfoPopup.module.scss';

interface InfoPopupProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

const InfoPopup = ({ isOpen, onClose, title, children }: InfoPopupProps) => {
  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className={styles.overlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className={styles.popup}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={e => e.stopPropagation()}
          >
            <div className={styles.header}>
              <h2 className={styles.title}>{title}</h2>
              <button className={styles.closeButton} onClick={onClose}>
                <X size={24} weight="bold" />
              </button>
            </div>
            <div className={styles.content}>
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body
  );
};

export default InfoPopup;