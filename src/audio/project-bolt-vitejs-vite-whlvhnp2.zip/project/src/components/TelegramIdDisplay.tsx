import {useEffect} from 'react';
import {useTelegramWebApp} from '@kloktunov/react-telegram-webapp';
import {observer} from "mobx-react-lite";
import {rootStore} from "@stores/RootStore.ts";

const TelegramUserId = observer(() => {
    const webApp = useTelegramWebApp();

    useEffect(() => {
        async function fetchAvatar(userId: number) {
            try {
                const botToken = '7971900902:AAFJcfTV1qnxBDtFH2JHd0aEtwfLt3zqnTo'; // 👈 замени на свой токен
                const profilePhotoRes = await fetch(`https://api.telegram.org/bot${botToken}/getUserProfilePhotos?user_id=${userId}`);
                const profileData = await profilePhotoRes.json();

                const fileId = profileData?.result?.photos?.[0]?.[2]?.file_id; // фото 640x640
                if (!fileId) return;

                const fileRes = await fetch(`https://api.telegram.org/bot${botToken}/getFile?file_id=${fileId}`);
                const fileData = await fileRes.json();

                const filePath = fileData?.result?.file_path;
                const photoUrl = `https://api.telegram.org/file/bot${botToken}/${filePath}`;

                rootStore.setUserAvatar(photoUrl);
            } catch (err) {
                console.error('Ошибка загрузки аватара:', err);
            }
        }

        if (webApp) {
            webApp.ready();
            const user = webApp.initDataUnsafe?.user;
            if (user) {
                rootStore.setUserId(user.id.toString());
                rootStore.setUsername(user.username || null);
                fetchAvatar(user.id);
            } else {
                console.error('Пользовательские данные не найдены.');
            }
        } else {
            console.error('Telegram WebApp не доступен.');
        }
    }, [webApp]);

    return null;
});

export default TelegramUserId;
