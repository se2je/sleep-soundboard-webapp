import {ReactNode} from 'react';
import {motion} from 'framer-motion';
import styles from './Button.module.scss';

interface ButtonProps {
    children: ReactNode;
    onClick?: () => void;
    disabled?: boolean;
    size?: 'default' | 'large';
    icon?: ReactNode;
    upper?: boolean;
    transparent?: boolean;
    round?: boolean;
    color?: 'white' | 'black' | 'blue';
}

const Button = ({
                    children,
                    onClick,
                    disabled,
                    size = 'default',
                    icon,
                    upper = false,
                    transparent = false,
                    round = false
                }: ButtonProps) => {
    return (
        <motion.button
            className={`
      ${styles.button} 
      ${size === 'large' ? styles.large : ''} 
      ${upper ? styles.uppercase : ''} 
      ${transparent && styles.transparent}
       ${round && styles.round}`}
            onClick={onClick}
            disabled={disabled}
            whileTap={{scale: disabled ? 1 : 0.95}}
        >
            {icon && <span className={styles.icon}>{icon}</span>}
            {children}
        </motion.button>
    );
};

export default Button;