import { NavLink } from 'react-router-dom';
import { House, GameController, User, Gear } from '@phosphor-icons/react';
import { motion } from 'framer-motion';
import styles from './BottomNavigation.module.scss';
import {useTranslation} from "react-i18next";

interface BottomNavigationProps {
  onSettingsClick: () => void;
}

const BottomNavigation = ({ onSettingsClick }: BottomNavigationProps) => {
    const { t } = useTranslation();

    return (
    <nav className={styles.navigation}>
      <NavLink 
        to="/" 
        className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
      >
        <House size={22} weight="bold" className={styles.icon} />
        <span className={styles.label}>{t('menu.home')}</span>
      </NavLink>

      <NavLink 
        to="/games" 
        className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
      >
        <GameController size={22} weight="bold" className={styles.icon} />
        <span className={styles.label}>{t('menu.games')}</span>
      </NavLink>

      <NavLink 
        to="/dashboard" 
        className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
      >
        <User size={22} weight="bold" className={styles.icon} />
        <span className={styles.label}>{t('menu.profile')}</span>
      </NavLink>

      <motion.button
        className={styles.navItem}
        onClick={onSettingsClick}
        whileTap={{ scale: 0.95 }}
      >
        <Gear size={22} weight="bold" className={styles.icon} />
        <span className={styles.label}>{t('menu.settings')}</span>
      </motion.button>
    </nav>
  );
};

export default BottomNavigation;