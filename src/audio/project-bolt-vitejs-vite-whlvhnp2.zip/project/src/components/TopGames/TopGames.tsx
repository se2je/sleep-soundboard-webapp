import { motion } from 'framer-motion';
import { Trophy, ChartLineUp, Dog, CircleNotch } from '@phosphor-icons/react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import styles from './TopGames.module.scss';

const GAMES = [
  {
    id: 'prediction',
    icon: ChartLineUp,
    path: '/games/prediction',
    name: 'prediction'

  },
  {
    id: 'roulette',
    icon: CircleNotch,
    path: '/games/roulette',
    name: 'roulette'

  },
  {
    id: 'farm',
    icon: Dog,
    path: '/games/farm',
    name: 'nftDogs'
  }
];

const TopGames = () => {
  const { t } = useTranslation();

  return (
    <motion.div 
      className={styles.topGames}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className={styles.header}>
        <Trophy size={24} weight="duotone" className={styles.icon} />
        <h2 className={styles.title}>{t('top_games.title')}</h2>
      </div>

      <div className={styles.gameGrid}>
        {GAMES.map((game) => (
          <Link 
            key={game.id} 
            to={game.path}
            className={styles.gameCard}
          >
            <div className={styles.iconWrapper}>
              <game.icon size={24} className={styles.gameIcon} />
            </div>
            <span className={styles.gameName}>
              {t(`games.${game.name}.title`)}
            </span>
          </Link>
        ))}
      </div>
    </motion.div>
  );
};

export default TopGames;