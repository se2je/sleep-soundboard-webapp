import { observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import { rootStore } from '@/stores/RootStore';
import styles from './LanguageSwitcher.module.scss';

interface LanguageSwitcherProps {
  disablePropagation?: boolean; // Пропс для отключения stopPropagation
}

const LanguageSwitcher = ({ disablePropagation = false }: LanguageSwitcherProps) => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'ru' : 'en';
    i18n.changeLanguage(newLang);
    rootStore.setLanguage(newLang);
  };

  const handleClick = (event: React.MouseEvent) => {
    if (disablePropagation) {
      event.stopPropagation(); // Останавливаем всплытие события, если пропс передан
    }
    toggleLanguage();
  };

  return (
      <button className={styles.switcher} onClick={handleClick}>
        {i18n.language === 'en' ? 'EN' : 'RU'}
      </button>
  );
};

export default observer(LanguageSwitcher);
