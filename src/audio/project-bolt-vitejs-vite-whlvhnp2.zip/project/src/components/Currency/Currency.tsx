import { observer } from 'mobx-react-lite';
import { motion, AnimatePresence } from 'framer-motion';
import styles from './Currency.module.scss';
import { rootStore } from "@stores/RootStore.ts";
import logo from '@media/logo.png';
import fun from '@media/fun.png';
import { Check } from '@phosphor-icons/react';
import { useEffect, useState } from 'react';

const Currency = observer(() => {
    const [showSuccess, setShowSuccess] = useState(false);
    const [prevTokens, setPrevTokens] = useState( rootStore.userDataStore.currency.tokens);
    const [prevGameCoins, setPrevGameCoins] = useState( rootStore.userDataStore.currency.gameCoins);
    const [highlightTokens, setHighlightTokens] = useState(false);
    const [highlightGameCoins, setHighlightGameCoins] = useState(false);

    useEffect(() => {
        if (rootStore.userDataStore.currency.tokens !== prevTokens ||
            rootStore.userDataStore.currency.gameCoins !== prevGameCoins) {
            setShowSuccess(true);
            if (rootStore.userDataStore.currency.tokens !== prevTokens) {
                setHighlightTokens(true);
            }
            if ( rootStore.userDataStore.currency.gameCoins !== prevGameCoins) {
                setHighlightGameCoins(true);
            }
            setPrevTokens(rootStore.userDataStore.currency.tokens);
            setPrevGameCoins( rootStore.userDataStore.currency.gameCoins);

            setTimeout(() => {
                setShowSuccess(false);
                setHighlightTokens(false);
                setHighlightGameCoins(false);
            }, 2000);
        }
    }, [rootStore.userDataStore.currency.tokens, rootStore.userDataStore.currency.gameCoins]);

    const formatNumber = (num: number) => {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    };

    return (
        <motion.div
            className={styles.currency}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
        >
            <div className={styles.currencyItem}>
                <img src={logo} className={styles.icon} alt="NFINE token" />
                <div className={styles.details}>
                    <span className={styles.label}>NFINE</span>
                    <AnimatePresence mode="wait">
                        <motion.span
                            className={`${styles.value} ${highlightTokens ? styles.highlight : ''}`}
                            key={ rootStore.userDataStore.currency.tokens}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                        >
                            {formatNumber( rootStore.userDataStore.currency.tokens)}
                        </motion.span>
                    </AnimatePresence>
                </div>
            </div>

            <div className={styles.currencyItem}>
                <img src={fun} className={styles.icon} alt="NFUN token" />
                <div className={styles.details}>
                    <span className={styles.label}>NFUN</span>
                    <AnimatePresence mode="wait">
                        <motion.span
                            className={`${styles.value} ${highlightGameCoins ? styles.highlight : ''}`}
                            key={ rootStore.userDataStore.currency.gameCoins}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                        >
                            {formatNumber( rootStore.userDataStore.currency.gameCoins)}
                        </motion.span>
                    </AnimatePresence>
                </div>
            </div>

            {showSuccess && (
                <AnimatePresence>
                    <motion.div
                        className={styles.successIndicator}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                    >
                        <Check weight="bold" className={styles.checkmark} />
                    </motion.div>
                </AnimatePresence>
            )}
        </motion.div>
    );
});

export default Currency;