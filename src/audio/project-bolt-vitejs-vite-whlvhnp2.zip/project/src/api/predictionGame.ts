export type Prediction = 'increase' | 'stable' | 'decrease';

export interface Round {
    round_id: number;
    start_time: string;
    end_time: string;
    initial_token_price: number;
    current_token_price: number;
    percentage_change: number;
    bet_pools: Record<string, number>;
    bets_amount: number;
    status: string;
    outcome: Prediction | null;
    prize_pool: number;
}

export interface UserBet {
    round_id: number;
    amount: number;
    prediction: Prediction;
    outcome: Prediction | null;
    won_amount: number;
}

const API = 'https://api.mysterytoken.org:8443';

// Получить все раунды
export const fetchRounds = async (): Promise<Round[]> => {
    const url = API + '/rounds';
    console.log('[GET]', url);
    const res = await fetch(url);
    const data = await res.json();
    console.log('[RESPONSE]', url, data);
    if (!res.ok) throw new Error('Failed to fetch rounds');
    return data;
};

// Получить текущий раунд
export const fetchCurrentRound = async (): Promise<string> => {
    const url = API + '/current-round';
    console.log('[GET]', url);
    const res = await fetch(url);
    const data = await res.text();
    console.log('[RESPONSE]', url, data);
    if (!res.ok) throw new Error('Failed to fetch current round');
    return data;
};

// Получить ставки пользователя
export const fetchUserBets = async (userId: number): Promise<UserBet[]> => {
    const url = API + `/user-bets/${userId}`;
    console.log('[GET]', url);
    const res = await fetch(url);
    const data = await res.json();
    console.log('[RESPONSE]', url, data);
    if (!res.ok) throw new Error('Failed to fetch user bets');
    return data;
};

// Получить статус ставок
export const fetchBettingStatus = async (): Promise<string> => {
    const url = API + '/betting-status';
    console.log('[GET]', url);
    const res = await fetch(url);
    const data = await res.text();
    console.log('[RESPONSE]', url, data);
    if (!res.ok) throw new Error('Failed to fetch betting status');
    return data;
};

// Сделать ставку
interface PlaceBetParams {
    userId: number;
    amount: number;
    prediction: Prediction;
}

export const placeBet = async ({ userId, amount, prediction }: PlaceBetParams) => {
    const url = API + `/place-bet/${userId}`;
    const body = { user_id: userId, amount, prediction };
    console.log('[POST]', url, body);

    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });

    const data = await res.json().catch(() => ({}));
    console.log('[RESPONSE]', url, data);

    if (!res.ok) throw new Error(data?.message || 'Failed to place bet');

    return data;
};
