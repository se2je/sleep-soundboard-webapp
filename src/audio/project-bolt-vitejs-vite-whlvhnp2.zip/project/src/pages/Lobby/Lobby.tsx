import { observer } from 'mobx-react-lite';
import { useState } from 'react';
import { rootStore } from '@/stores/RootStore';
import Header from '@/components/Header/Header';
import SettingsMenu from '@/components/Settings/SettingsMenu';
import TopGames from '@/components/TopGames/TopGames';
import Updates from '@/components/Updates/Updates';
import CheckInSection from './sections/CheckInSection';
import DevelopmentInfo from '@/components/DevelopmentInfo/DevelopmentInfo';
import styles from './Lobby.module.scss';
import ErrorTooltip from "@components/ErrorTooltip/ErrorTooltip.tsx";
import gold_dog from '@media/goldog.png';
import { motion } from 'framer-motion';

const Lobby = () => {
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    if (rootStore.isLoading) {
        return (
            <div className={styles.container}>
                <span className={styles.loading}></span>
            </div>
        );
    }


    return (
        <div className={styles.container}>
            <ErrorTooltip />

            <Header 
              showCurrency={true}
              showProfile={true}
            />

            <div className={styles.mainContent}>
                <CheckInSection />
                <Updates />

                <div className={styles.topRow}>
                    <DevelopmentInfo />
                    <TopGames />
                </div>

                <motion.img
                    className={styles.goldDog}
                    src={gold_dog}
                    alt=""
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                />
            </div>

            <footer className={styles.footer}>
                © 2025 Mystery TON Token. All rights reserved
            </footer>

            <SettingsMenu isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
        </div>
    );
};

export default observer(Lobby);