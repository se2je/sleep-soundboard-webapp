import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { observer } from 'mobx-react-lite';
import { rootStore } from '@/stores/RootStore';
import Button from '@/components/Button/Button';
import StreakInfo from '@/components/StreakInfo/StreakInfo';
import styles from '../Lobby.module.scss';

const CheckInSection = observer(() => {
  const { t } = useTranslation();

  return (
    <div className={styles.checkInSection}>
      <StreakInfo />

      <motion.div
        className={styles.comboInfo}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className={styles.comboInfoText}>
          {t('lobby.combo', { days: rootStore.userDataStore.comboStreak })}
          <motion.span
            className={styles.comboValue}
            key={rootStore.userDataStore.comboStreak}
            initial={{ scale: 0.5 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 500 }}
          >
            {' ' + rootStore.userDataStore.comboStreak}
          </motion.span>
          {' ' + t('lobby.days')}
        </div>

        {rootStore.userDataStore.maxComboStreak > 0 && (
          <div className={styles.maxCombo}>
            {t('lobby.maxCombo', { days: rootStore.userDataStore.maxComboStreak })}
          </div>
        )}
      </motion.div>

      <Button
        transparent
        round
        onClick={() => rootStore.userDataStore.checkIn(rootStore.userStore.userId)}
      >
        {t('lobby.checkIn')}
      </Button>

      {rootStore.checkInStore.isCheckedIn && (
        <AnimatePresence>
          <motion.p
            className={styles.message}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            {t('lobby.comeBackTomorrow')}
          </motion.p>
        </AnimatePresence>
      )}
    </div>
  );
});

export default CheckInSection;