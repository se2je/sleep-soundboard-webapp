import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CaretLeft, Dog, Info, CaretDown, CaretUp } from '@phosphor-icons/react';
import { Link } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import Currency from '@/components/Currency/Currency';
import InfoPopup from '@/components/InfoPopup/InfoPopup';
import styles from './FarmGame.module.scss';

interface NFTDog {
  id: number;
  name: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  farmRate: number;
  farmDuration: number;
  restDuration: number;
  farmingEndTime: number | null;
  tokenType: 'NFUN' | 'NFINE';
}

const RARITIES = {
  common: { color: '#8BC34A', chance: 0.6, multiplier: 1 },
  rare: { color: '#2196F3', chance: 0.25, multiplier: 2 },
  epic: { color: '#9C27B0', chance: 0.1, multiplier: 4 },
  legendary: { color: '#FFD700', chance: 0.05, multiplier: 8 }
};

const NFINE_DOG_PRICES = [
  { price: 5000, rarity: 'common' },
  { price: 10000, rarity: 'rare' },
  { price: 100000, rarity: 'epic' },
  { price: 500000, rarity: 'legendary' }
];

const FREE_DOG_COOLDOWN = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds

const DEFAULT_DOG: NFTDog = {
  id: 1,
  name: "Starter Dog",
  rarity: 'common',
  farmRate: 0.1,
  farmDuration: 6 * 60 * 60 * 1000, // 6 hours
  restDuration: 2 * 60 * 60 * 1000, // 2 hours
  farmingEndTime: null,
  tokenType: 'NFUN'
};

const FarmGame = observer(() => {
  const [dogs, setDogs] = useState<NFTDog[]>([DEFAULT_DOG]);
  const [expandedDogs, setExpandedDogs] = useState<number[]>([]);
  const [lastFreeDogClaim, setLastFreeDogClaim] = useState<number>(0);
  const [showBuyPopup, setShowBuyPopup] = useState(false);
  const {t} = useTranslation();

  useEffect(() => {
    const interval = setInterval(() => {
      setDogs(currentDogs => 
        currentDogs.map(dog => {
          if (dog.farmingEndTime && Date.now() >= dog.farmingEndTime) {
            return { ...dog, farmingEndTime: null };
          }
          return dog;
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const startFarming = (dogId: number) => {
    setDogs(currentDogs =>
      currentDogs.map(dog => {
        if (dog.id === dogId) {
          return {
            ...dog,
            farmingEndTime: Date.now() + dog.farmDuration
          };
        }
        return dog;
      })
    );
  };

  const getFarmingProgress = (dog: NFTDog) => {
    if (!dog.farmingEndTime) return 0;
    const elapsed = dog.farmingEndTime - Date.now();
    const progress = 100 - (elapsed / dog.farmDuration) * 100;
    return Math.max(0, Math.min(100, progress));
  };

  const formatTimeLeft = (dog: NFTDog) => {
    if (!dog.farmingEndTime) return '';
    const timeLeft = Math.max(0, dog.farmingEndTime - Date.now());
    const hours = Math.floor(timeLeft / 3600000);
    const minutes = Math.floor((timeLeft % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };

  const toggleDogStats = (dogId: number) => {
    setExpandedDogs(prev => 
      prev.includes(dogId) 
        ? prev.filter(id => id !== dogId)
        : [...prev, dogId]
    );
  };

  const formatDuration = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    return `${hours} hours`;
  };

  const canClaimFreeDog = () => {
    return Date.now() - lastFreeDogClaim >= FREE_DOG_COOLDOWN;
  };

  const claimFreeDog = () => {
    if (!canClaimFreeDog()) return;
    
    const newDog: NFTDog = {
      id: Date.now(),
      name: `Dog #${dogs.length + 1}`,
      rarity: 'common',
      farmRate: 0.1,
      farmDuration: 6 * 60 * 60 * 1000,
      restDuration: 2 * 60 * 60 * 1000,
      farmingEndTime: null,
      tokenType: 'NFUN'
    };
    
    setDogs(prev => [...prev, newDog]);
    setLastFreeDogClaim(Date.now());
  };

  const buyNfineDog = (_price: number, rarity: string) => {
    const newDog: NFTDog = {
      id: Date.now(),
      name: `Premium Dog #${dogs.length + 1}`,
      rarity: rarity as 'common' | 'rare' | 'epic' | 'legendary',
      farmRate: 0.2 * RARITIES[rarity as keyof typeof RARITIES].multiplier,
      farmDuration: 3 * 60 * 60 * 1000,
      restDuration: 1 * 60 * 60 * 1000,
      farmingEndTime: null,
      tokenType: 'NFINE'
    };
    
    setDogs(prev => [...prev, newDog]);
    setShowBuyPopup(false);
  };

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <Link to="/games">
          <motion.button
            className={styles.backButton}
            whileHover={{ x: -5 }}
            whileTap={{ scale: 0.95 }}
          >
            <CaretLeft size={24} weight="bold" />
          </motion.button>
        </Link>
        <Currency />
      </header>

      <div className={styles.developmentNotice}>
        <Info size={24} weight="duotone" />
        <p>{t('games.preview')}</p>
      </div>

      <div className={styles.farmContent}>
        <div className={styles.dogActions}>
          <div className={styles.actionButtons}>
            <motion.button
              className={`${styles.actionButton} ${styles.freeButton}`}
              onClick={claimFreeDog}
              disabled={!canClaimFreeDog()}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {t('games.nftDogs.buttons.claimFree')}
              {!canClaimFreeDog() && (
                <span className={styles.cooldown}>
                  {t('games.nftDogs.buttons.available', {
                    time: formatDuration(FREE_DOG_COOLDOWN - (Date.now() - lastFreeDogClaim))
                  })}
                </span>
              )}
            </motion.button>

            <motion.button
              className={`${styles.actionButton} ${styles.buyButton}`}
              onClick={() => setShowBuyPopup(true)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {t('games.nftDogs.buttons.buyNfine')}
            </motion.button>
          </div>
        </div>

        <InfoPopup
          isOpen={showBuyPopup}
          onClose={() => setShowBuyPopup(false)}
          title={t('games.nftDogs.buyOptions.title')}
        >
          <div className={styles.buyMenu}>
            {NFINE_DOG_PRICES.map(({ price, rarity }) => (
              <motion.button
                key={rarity}
                className={styles.buyOption}
                onClick={() => buyNfineDog(price, rarity)}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                style={{
                  borderColor: RARITIES[rarity as keyof typeof RARITIES].color
                }}
              >
                {t(`games.nftDogs.rarities.${rarity}`)} - {t(`games.nftDogs.buyOptions.prices.${rarity}`)}
              </motion.button>
            ))}
          </div>
        </InfoPopup>

        <div className={styles.dogsCounter}>
          <Dog size={24} weight="duotone" />
          <span>Total Dogs: {dogs.length}</span>
        </div>

        <div className={styles.dogsGrid}>
          {dogs.map(dog => (
            <motion.div
              key={dog.id}
              className={styles.dogCard}
              style={{
                borderColor: RARITIES[dog.rarity].color,
                boxShadow: `0 0 10px ${RARITIES[dog.rarity].color}33`
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <div className={styles.dogHeader}>
                <div className={styles.dogIcon}>
                  <Dog size={32} weight="duotone" />
                </div>
                <h3 className={styles.dogName}>{dog.name}</h3>
                <motion.button
                  className={styles.expandButton}
                  onClick={() => toggleDogStats(dog.id)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {expandedDogs.includes(dog.id) ? (
                    <CaretUp size={20} weight="bold" />
                  ) : (
                    <CaretDown size={20} weight="bold" />
                  )}
                </motion.button>
              </div>

              <div className={styles.dogInfo}>
                <span className={styles.rarity} style={{ color: RARITIES[dog.rarity].color }}>
                  {t(`games.nftDogs.rarities.${dog.rarity}`)}
                </span>
                <span className={styles.tokenType}>{dog.tokenType}</span>
              </div>

              {expandedDogs.includes(dog.id) && (
                <motion.div
                  className={styles.statsBlock}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                >
                  <div className={styles.statRow}>
                    <span>{t('games.nftDogs.stats.farmSpeed')}:</span>
                    <span>{dog.farmRate.toFixed(1)} {dog.tokenType}/min</span>
                  </div>
                  <div className={styles.statRow}>
                    <span>{t('games.nftDogs.stats.farmDuration')}:</span>
                    <span>{formatDuration(dog.farmDuration)}</span>
                  </div>
                  <div className={styles.statRow}>
                    <span>{t('games.nftDogs.stats.restTime')}:</span>
                    <span>{formatDuration(dog.restDuration)}</span>
                  </div>
                </motion.div>
              )}

              <motion.button
                className={styles.farmButton}
                onClick={() => !dog.farmingEndTime && startFarming(dog.id)}
                disabled={dog.farmingEndTime !== null}
                whileHover={{ scale: dog.farmingEndTime ? 1 : 1.05 }}
                whileTap={{ scale: dog.farmingEndTime ? 1 : 0.95 }}
              >
                <div 
                  className={styles.farmProgress} 
                  style={{ width: `${getFarmingProgress(dog)}%` }} 
                />
                <div className={styles.farmButtonContent}>
                  {dog.farmingEndTime
                    ? t('games.nftDogs.buttons.farming', { time: formatTimeLeft(dog) })
                    : t('games.nftDogs.buttons.startFarming')
                  }
                </div>
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
});

export default FarmGame;