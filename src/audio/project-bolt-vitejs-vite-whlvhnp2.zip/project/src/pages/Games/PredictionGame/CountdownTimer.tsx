import { useEffect, useState } from 'react';

interface CountdownTimerProps {
    timeLeft: number;
}

const formatTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);

    return `${hours.toString().padStart(2, '0')}:${minutes
        .toString()
        .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};

const CountdownTimer = ({ timeLeft }: CountdownTimerProps) => {
    const [formatted, setFormatted] = useState(formatTime(timeLeft));

    useEffect(() => {
        setFormatted(formatTime(timeLeft));
    }, [timeLeft]);

    return <span>{formatted}</span>;
};

export default CountdownTimer;
