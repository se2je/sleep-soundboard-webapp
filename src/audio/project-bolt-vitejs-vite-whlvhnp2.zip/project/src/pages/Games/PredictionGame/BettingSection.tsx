import { useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, ArrowDown, Minus } from '@phosphor-icons/react';
import { useTranslation } from 'react-i18next';

import { Prediction } from '@/api/predictionGame';
import { rootStore } from '@/stores/RootStore';

import styles from './PredictionGame.module.scss';

interface BettingSectionProps {
    minimumBet: number;
    onBet: (amount: number, direction: Prediction) => void;
}

const BettingSection = ({ minimumBet, onBet }: BettingSectionProps) => {
    const { t } = useTranslation();
    const [betAmount, setBetAmount] = useState('');
    const [selectedOption, setSelectedOption] = useState<Prediction | null>(null);

    const userBalance = rootStore.userDataStore.currency.gameCoins;

    const isInvalidAmount = useMemo(() => {
        const num = parseFloat(betAmount);
        return isNaN(num) || num < minimumBet || num > userBalance;
    }, [betAmount, minimumBet, userBalance]);

    const handleSubmit = useCallback(() => {
        const amount = parseFloat(betAmount);

        if (!selectedOption || isInvalidAmount) {
            rootStore.uiStore.setErrorMessage(t('errors.invalidBet'));
            return;
        }

        onBet(amount, selectedOption);
        setBetAmount('');
        setSelectedOption(null);
    }, [betAmount, selectedOption, isInvalidAmount, onBet, t]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setBetAmount(value);

        const numericValue = parseFloat(value);
        if (!isNaN(numericValue) && numericValue > userBalance) {
            rootStore.uiStore.setErrorMessage(t('errors.insufficientFunds'));
        } else {
            rootStore.uiStore.setErrorMessage('');
        }
    };

    const renderOption = (
        value: Prediction,
        Icon: React.ElementType,
        labelKey: string,
        styleClass: string
    ) => (
        <motion.div
            key={value}
            className={`${styles.betOption} ${styleClass} ${selectedOption === value ? styles.selected : ''}`}
            onClick={() => setSelectedOption(value)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
        >
            <Icon size={24} className={styles.optionIcon} />
            <div className={styles.optionLabel}>{t(labelKey)}</div>
        </motion.div>
    );

    return (
        <div className={styles.bettingSection}>
            <div className={styles.inputGroup}>
                <input
                    type="number"
                    className={styles.betInput}
                    value={betAmount}
                    onChange={handleInputChange}
                    placeholder={`${minimumBet} NFUN`}
                    min={minimumBet}
                />
            </div>

            <div className={styles.betOptions}>
                {renderOption('increase', ArrowUp, 'games.prediction.options.increase', styles.increase)}
                {renderOption('stable', Minus, 'games.prediction.options.stable', styles.stable)}
                {renderOption('decrease', ArrowDown, 'games.prediction.options.decrease', styles.decrease)}
            </div>

            <motion.button
                className={styles.placeBetButton}
                onClick={handleSubmit}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={!selectedOption || isInvalidAmount}
            >
                {t('games.prediction.placeBet')}
            </motion.button>
        </div>
    );
};

export default BettingSection;
