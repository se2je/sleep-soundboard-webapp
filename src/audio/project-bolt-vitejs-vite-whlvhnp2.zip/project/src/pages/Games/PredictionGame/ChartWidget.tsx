import { useEffect, useRef } from "react";

// Расширяем глобальный объект window
declare global {
    interface Window {
        TradingView?: {
            widget: new (options: Record<string, unknown>) => void;
        };
    }
}
const TradingViewWidget: React.FC = () => {
    const containerRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (!containerRef.current) return;

        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/tv.js";
        script.async = true;

        script.onload = () => {
            if (window.TradingView?.widget) {
                new window.TradingView.widget({
                    width: "100%",
                    height: 300,
                    symbol: "BINANCE:TONUSDT",
                    interval: "30",
                    timezone: "Etc/UTC",
                    theme: "dark",
                    style: "1",
                    locale: "en",
                    toolbar_bg: "#f1f3f6",
                    enable_publishing: false,
                    hide_top_toolbar: true,
                    container_id: "tradingview_widget",
                    hide_legend: true,
                });
            }
        };

        containerRef.current.appendChild(script);
    }, []);

    return (
        <div ref={containerRef}>
            <div id="tradingview_widget" />
        </div>
    );
};

export default TradingViewWidget;
