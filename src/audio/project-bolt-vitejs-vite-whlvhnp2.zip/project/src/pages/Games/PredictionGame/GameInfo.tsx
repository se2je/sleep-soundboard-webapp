import {useState} from 'react';
import {Question} from '@phosphor-icons/react';
import {motion} from 'framer-motion';
import {useTranslation} from 'react-i18next';
import InfoPopup from '@/components/InfoPopup/InfoPopup';
import styles from './GameInfo.module.scss';

const GameInfo = () => {
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const {t} = useTranslation();

    return (
        <>
            <motion.div
                className={styles.infoSection}
                initial={{opacity: 0, y: 20}}
                animate={{opacity: 1, y: 0}}
            >
                <p className={styles.description}>
                    {t('games.prediction.info.short')}
                </p>
                <motion.button
                    className={styles.infoButton}
                    onClick={() => setIsPopupOpen(true)}
                    whileHover={{scale: 1.1}}
                    whileTap={{scale: 0.9}}
                >
                    <Question size={24} weight="bold"/>
                </motion.button>
            </motion.div>

            <InfoPopup
                isOpen={isPopupOpen}
                onClose={() => setIsPopupOpen(false)}
                title={t('games.prediction.info.howToPlay.title')}
            >
                <div className={styles.rulesContent}>
                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>  {t('games.prediction.info.howToPlay.sections.gameOverview.title')}</h3>
                        <p className={styles.text}>
                            {t('games.prediction.info.howToPlay.sections.gameOverview.text')}
                        </p>
                    </div>

                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}> {t('games.prediction.info.howToPlay.sections.howItWorks.title')}</h3>
                        <ul>
                            {(t('games.prediction.info.howToPlay.sections.howItWorks.steps', { returnObjects: true }) as string[]).map(
                                (step, index) => (
                                    <li key={index}>{step}</li>
                                )
                            )}
                        </ul>
                    </div>

                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>{t('games.prediction.info.howToPlay.sections.roundDuration.title')}</h3>
                        <ul>
                            {Object.entries(t('games.prediction.info.howToPlay.sections.roundDuration.durations', {returnObjects: true}))
                                .map(([key, value], index) => (
                                    <li key={index}>
                                        {key}: {value}
                                    </li>
                                ))}
                        </ul>
                    </div>

                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>{t('games.prediction.info.howToPlay.sections.winningConditions.title')}</h3>
                        <ul>
                            {Object.entries(t('games.prediction.info.howToPlay.sections.winningConditions.conditions', {returnObjects: true}))
                                .map(([key, value], index) => (
                                    <li key={index}>
                                        {key}: {value}
                                    </li>
                                ))}
                        </ul>
                    </div>

                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>{t('games.prediction.info.howToPlay.sections.tips.title')}</h3>
                        <ul>
                            {(t('games.prediction.info.howToPlay.sections.tips.list', { returnObjects: true }) as string[]).map(
                                (step, index) => (
                                    <li key={index}>{step}</li>
                                )
                            )}
                        </ul>
                    </div>
                </div>
            </InfoPopup>
        </>
    );
};

export default GameInfo;