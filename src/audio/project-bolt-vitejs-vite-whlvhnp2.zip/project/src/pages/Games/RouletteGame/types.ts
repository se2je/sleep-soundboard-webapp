export interface PrizeStyle {
  backgroundColor: string;
  textColor: string;
  fontSize?: number; // можно сделать необязательным, если ты не используешь текст
}

export interface PrizeData {
  key: string;
  option?: string;
  image?: {
    uri: string;
    sizeMultiplier?: number; // уменьшает размер картинки
    landscape?: boolean;
  };
  style: PrizeStyle;
}
