import {PrizeData} from './types';
import CASE from '@media/Case.png';
import KEY from '@media/Key.png';
import TICKET from '@media/Ticket.png'
import MONEY from '@media/Money_1.png'
import MONEY_1 from '@media/Money_2.png'
import DIAMOND from '@media/Diamond.png'
import COINS from '@media/Coins.png'
import KEY_1 from '@media/Key_icon.png'

export const PRIZE_ICONS = {
    case: CASE,
    key: KEY,
    ticket: TICKET,
    money: MONEY,
    money_1: MONEY_1,
    diamond: DIAMOND,
    coins: COINS,
    key_1: KEY_1,

};

export const PRIZE_TEXTS = {
    case: '1 Case!',
    key: '1 Key!',
    ticket: 'X Tickets!',
    money: 'X NFINE!',
    money_1: 'X NFINE!',
    diamond: 'X TON!',
    coins: 'X NFUN',
    key_1: 'X Keys!',
};

export const PRIZES: PrizeData[] = [
    { key: 'case', image: { uri: PRIZE_ICONS.case, sizeMultiplier: 0.6 }, style: { backgroundColor: '#ab3c20', textColor: 'white' } },
    { key: 'key', image: { uri: PRIZE_ICONS.key, sizeMultiplier: 0.6 }, style: { backgroundColor: '#024e70', textColor: 'white' } },
    { key: 'diamond', image: { uri: PRIZE_ICONS.diamond, sizeMultiplier: 0.6 }, style: { backgroundColor: '#cc700b', textColor: 'white' } },
    { key: 'key_1', image: { uri: PRIZE_ICONS.key_1, sizeMultiplier: 0.6 }, style: { backgroundColor: '#0f4456', textColor: 'white' } },
    { key: 'ticket', image: { uri: PRIZE_ICONS.ticket, sizeMultiplier: 0.6 }, style: { backgroundColor: '#002f53', textColor: 'white' } },
    { key: 'coins', image: { uri: PRIZE_ICONS.coins, sizeMultiplier: 0.6 }, style: { backgroundColor: '#8f3a04', textColor: 'white' } },
    { key: 'money', image: { uri: PRIZE_ICONS.money, sizeMultiplier: 0.6 }, style: { backgroundColor: '#004f60', textColor: 'white' } },
    { key: 'money_1', image: { uri: PRIZE_ICONS.money_1, sizeMultiplier: 0.6 }, style: { backgroundColor: '#004054', textColor: 'white' } },
];

