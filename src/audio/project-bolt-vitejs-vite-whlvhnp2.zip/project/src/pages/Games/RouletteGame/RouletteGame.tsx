import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Ticket, Question, Info } from '@phosphor-icons/react';
import { observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import { Wheel } from 'react-custom-roulette';
import InfoPopup from '@/components/InfoPopup/InfoPopup';
import Header from '@components/Header/Header.tsx';
import { PRIZES, PRIZE_TEXTS, PRIZE_ICONS } from './rouletteData';
import styles from './RouletteGame.module.scss';
import logo from '@media/noback.png';
import { rootStore } from '@stores/RootStore.ts';

const RouletteGame = observer(() => {
    const [mustSpin, setMustSpin] = useState(false);
    const [prizeNumber, setPrizeNumber] = useState(0);
    const [isInfoOpen, setIsInfoOpen] = useState(false);
    const [showPrizePopup, setShowPrizePopup] = useState(false);
    const { t } = useTranslation();

    const tickets = rootStore.userDataStore.tickets;

    const handleSpinClick = async () => {
        if (mustSpin || tickets < 1) return;

        const success = await rootStore.userDataStore.spendTicket();
        if (!success) return;

        const newPrizeNumber = Math.floor(Math.random() * PRIZES.length);
        setPrizeNumber(newPrizeNumber);
        setMustSpin(true);
    };

    const handleSpinStop = () => {
        setMustSpin(false);
        setShowPrizePopup(true);
    };

    const getPrizeIconUrl = (prizeNumber: number) => {
        const key = PRIZES[prizeNumber].key;
        // @ts-expect-error/NOERROR
        return PRIZE_ICONS[key];
    };

    const getPrizeText = (prizeNumber: number) => {
        const key = PRIZES[prizeNumber].key;
        // @ts-expect-error/NOERROR
        return PRIZE_TEXTS[key];
    };

    return (
        <div className={styles.container}>
            <Header
                showBack={true}
                title={t('tabs.gameTitles.roulette')}
                showProfile={false}
            />
            <div className={styles.developmentNotice}>
                <Info className={styles.icon} size={24} weight="duotone" />
                <p>{t('games.preview')}</p>
            </div>

            <div className={styles.gameContent}>
                <div className={styles.controlsSection}>
                    <div className={styles.rouletteInfo}>
                        <div className={styles.keyInfo}>
                            <Ticket size={24} weight="duotone" />
                            <span>{t('games.roulette.keyInfo')}: {tickets}</span>
                            <motion.button
                                className={styles.infoButton}
                                onClick={() => setIsInfoOpen(true)}
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                            >
                                <Question size={20} weight="bold" />
                            </motion.button>
                        </div>
                    </div>

                    <motion.button
                        className={styles.spinButton}
                        onClick={handleSpinClick}
                        disabled={mustSpin || tickets < 1}
                        whileHover={{ scale: mustSpin ? 1 : 1.05 }}
                        whileTap={{ scale: mustSpin ? 1 : 0.95 }}
                    >
                        {mustSpin ? t('games.roulette.spinningButton') : t('games.roulette.spinButton')}
                    </motion.button>
                </div>

                <div className={styles.wheelWrapper}>
                    <Wheel
                        mustStartSpinning={mustSpin}
                        prizeNumber={prizeNumber}
                        data={PRIZES}
                        onStopSpinning={handleSpinStop}
                        outerBorderColor="#e5a156"
                        outerBorderWidth={8}
                        innerRadius={30}
                        innerBorderColor="#e5a156"
                        innerBorderWidth={3}
                        radiusLineColor="#040b1b"
                        radiusLineWidth={2}
                        spinDuration={0.8}
                        perpendicularText={true}
                        textDistance={80}
                    />
                    <div className={styles.wheelInnerCircle}>
                        <img src={logo} alt="Wheel center" />
                    </div>
                </div>
            </div>

            <AnimatePresence>
                {showPrizePopup && (
                    <>
                        <motion.div
                            className={styles.overlay}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setShowPrizePopup(false)}
                        />
                        <motion.div
                            className={styles.prizePopup}
                            initial={{ scale: 0.5, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.5, opacity: 0 }}
                        >
                            <div className={styles.prizeIcon}>
                                <img src={getPrizeIconUrl(prizeNumber)} alt="Prize" />
                            </div>
                            <h2 className={styles.prizeTitle}>{t('games.roulette.prizes.congratulations')}</h2>
                            <div className={styles.prizeAmount}>
                                {getPrizeText(prizeNumber)}
                            </div>
                            <button
                                className={styles.closeButton}
                                onClick={() => setShowPrizePopup(false)}
                            >
                                {t('games.roulette.prizes.claim')}
                            </button>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            <InfoPopup
                isOpen={isInfoOpen}
                onClose={() => setIsInfoOpen(false)}
                title={t('games.roulette.howToPlay.title')}
            >
                <div className={styles.infoContent}>
                    <h3>{t('games.roulette.howToPlay.title')}</h3>
                    <p>{t('games.roulette.howToPlay.description')}</p>

                    <h3>{t('games.roulette.prizes.title')}</h3>
                    <div className={styles.prizesList}>
                        {Object.entries(PRIZE_TEXTS).map(([key, value]) => (
                            <div key={key} className={styles.prizeItem}>
                                <img
                                    src={PRIZE_ICONS[key as keyof typeof PRIZE_ICONS]}
                                    alt={key}
                                    style={{ width: '24px', height: '24px', marginRight: '8px' }}
                                />
                                {value}
                            </div>
                        ))}
                    </div>

                    <h3>{t('games.roulette.keyInfo')}</h3>
                    <p>{t('games.roulette.howToPlay.keyGeneration')}</p>
                </div>
            </InfoPopup>
        </div>
    );
});

export default RouletteGame;
