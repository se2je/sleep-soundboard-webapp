import { motion } from 'framer-motion';
import {
    Crown,
    Sparkle,
    ChartLineUp,
    ShoppingCart,
    User,
    CheckCircle
} from '@phosphor-icons/react';
import { observer } from 'mobx-react-lite';
import { rootStore } from '@/stores/RootStore';
import Inventory from '@/components/Inventory/Inventory';
import styles from './Dashboard.module.scss';
import Header from "@components/Header/Header.tsx";
import { useState } from "react";
import SettingsMenu from "@components/Settings/SettingsMenu.tsx";
import { useTranslation } from "react-i18next";
import { ReactElement } from "react";

// Типы для уровней кармы
type KarmaLevelKey = 'NOVICE' | 'FARMER' | 'MASTER';

type KarmaLevel = {
    key: KarmaLevelKey;
    min: number;
    max: number;
    title: string;
};

const KARMA_LEVELS: Record<KarmaLevelKey, KarmaLevel> = {
    NOVICE: { key: 'NOVICE', min: 0, max: 299, title: 'Новичок' },
    FARMER: { key: 'FARMER', min: 300, max: 699, title: 'Фермер' },
    MASTER: { key: 'MASTER', min: 700, max: 999, title: 'Бог фарма' },
};

// Тип для бонусов
type Bonus = {
    icon: ReactElement;
    text: string;
};

const BONUSES_BY_LEVEL: Record<Exclude<KarmaLevelKey, 'NOVICE'>, Bonus[]> = {
    FARMER: [
        { icon: <ChartLineUp size={24} weight="duotone" />, text: '+5% к фарму монет' },
    ],
    MASTER: [
        { icon: <ChartLineUp size={24} weight="duotone" />, text: '+5% к фарму монет' },
        { icon: <ShoppingCart size={24} weight="duotone" />, text: '+2% скидка на маркете' },
    ],
};

const Dashboard = observer(() => {
    const { t } = useTranslation();
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    const karmaScore: number = rootStore.userDataStore.karma;
    const maxKarma = 1000;

    const getCurrentLevel = (karma: number): KarmaLevel => {
        if (karma >= KARMA_LEVELS.MASTER.min) return KARMA_LEVELS.MASTER;
        if (karma >= KARMA_LEVELS.FARMER.min) return KARMA_LEVELS.FARMER;
        return KARMA_LEVELS.NOVICE;
    };

    const currentLevel = getCurrentLevel(karmaScore);
    const bonuses = BONUSES_BY_LEVEL[currentLevel.key as 'FARMER' | 'MASTER'] || [];

    const progressToNextLevel = ((karmaScore - currentLevel.min) /
        (currentLevel.max - currentLevel.min)) * 100;

    return (
        <div className={styles.container}>
            <Header
                showBack={true}
                title={t('tabs.dashboard')}
                showProfile={false}
            />

            <div className={styles.content}>
                <motion.div
                    className={styles.profileSection}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <motion.div className={styles.avatar} whileHover={{ scale: 1.05 }}>
                        <div className={styles.avatarInner}>
                            {rootStore.userStore.avatarUrl ? (
                                <img src={rootStore.userStore.avatarUrl} alt="User Avatar" />
                            ) : (
                                <User size={40} weight="duotone" className={styles.avatarIcon} />
                            )}
                        </div>
                    </motion.div>

                    <div className={styles.userInfo}>
                        <h2 className={styles.username}>
                            {rootStore.userStore.username || 'Mystery User'}
                            <CheckCircle size={20} weight="fill" className={styles.verifiedBadge} />
                        </h2>
                        <div className={styles.userId}>
                            ID: {rootStore.userStore.userId || 'Unknown'}
                        </div>
                    </div>

                    <div className={styles.rank}>
                        <Sparkle size={20} weight="duotone" />
                        {currentLevel.title}
                    </div>
                </motion.div>

                <motion.div
                    className={styles.karmaSection}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <div className={styles.karmaHeader}>
                        <Crown size={48} weight="duotone" className={styles.icon} />
                        <div>
                            <h1 className={styles.title}>Твоя Карма</h1>
                            <p className={styles.description}>
                                Твоя карма говорит за тебя. Чем выше — тем круче фармишь и торгуешь.
                            </p>
                        </div>
                    </div>

                    <div className={styles.karmaStats}>
                        <div className={styles.score}>
                            {karmaScore}
                            <span className={styles.maxScore}>/{maxKarma}</span>
                        </div>
                    </div>

                    <div className={styles.progressWrapper}>
                        <div className={styles.progressBar}>
                            <motion.div
                                className={styles.progress}
                                initial={{ width: 0 }}
                                animate={{ width: `${progressToNextLevel}%` }}
                                transition={{ duration: 1, ease: "easeOut" }}
                            />
                        </div>
                    </div>

                    {bonuses.length > 0 && (
                        <div className={styles.bonusesList}>
                            {bonuses.map((bonus, index) => (
                                <motion.div
                                    key={index}
                                    className={styles.bonusItem}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                >
                                    <span className={styles.bonusIcon}>{bonus.icon}</span>
                                    <span className={styles.bonusText}>{bonus.text}</span>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </motion.div>

                <Inventory />
            </div>

            <SettingsMenu isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
        </div>
    );
});

export default Dashboard;
