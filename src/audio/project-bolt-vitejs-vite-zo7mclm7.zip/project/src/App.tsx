import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import {observer} from 'mobx-react-lite';
import {useState} from 'react';
import Lobby from '@/pages/Lobby/Lobby';
import Games from '@/pages/Games/Games';
import PredictionGame from '@/pages/Games/PredictionGame/PredictionGame';
import RouletteGame from '@/pages/Games/RouletteGame/RouletteGame';
import FarmGame from '@/pages/Games/FarmGame/FarmGame';
import Dashboard from '@/pages/Dashboard/Dashboard';
import BottomNavigation from '@/components/BottomNavigation/BottomNavigation';
import SettingsMenu from '@/components/Settings/SettingsMenu';
import styles from './App.module.scss';
import {TelegramWebApp} from '@kloktunov/react-telegram-webapp';
import TelegramUserId from "@components/TelegramIdDisplay.tsx";

const App = observer(() => {
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    return (
        <TelegramWebApp>
            <Router>
                <div className={styles.app}>
                    <TelegramUserId/>
                    <Routes>
                        <Route path="/" element={<Lobby/>}/>
                        <Route path="/games" element={<Games/>}/>
                        <Route path="/games/prediction" element={<PredictionGame/>}/>
                        <Route path="/games/roulette" element={<RouletteGame/>}/>
                        <Route path="/games/farm" element={<FarmGame/>}/>
                        <Route path="/dashboard" element={<Dashboard/>}/>
                    </Routes>
                    <BottomNavigation onSettingsClick={() => setIsSettingsOpen(true)} />
                    <SettingsMenu isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
                </div>
            </Router>
        </TelegramWebApp>
    );
});

export default App;