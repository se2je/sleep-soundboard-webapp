import { makeAutoObservable } from 'mobx';
import type { RootStore } from './RootStore';

export class UserStore {
    userId: string | null = null;
    username: string | null = null;
    avatarUrl: string | null = null;

    constructor(private root: RootStore) {
        makeAutoObservable(this);
    }

    setUserId(userId: string) {
        this.userId = userId;
        this.root.userDataStore.fetchUserData(userId);
    }

    setUsername(username: string | null) {
        this.username = username;
    }

    setAvatarUrl(url: string | null) {
        this.avatarUrl = url;
    }
}
