import { UserStore } from './UserStore';
import { UserDataStore } from './UserDataStore';
import { UiStore } from './UiStore';
import { CheckInStore } from './CheckInStore';

export class RootStore {
    userStore: UserStore;
    userDataStore: UserDataStore;
    uiStore: UiStore;
    checkInStore: CheckInStore;

    constructor() {
        this.uiStore = new UiStore(this);
        this.userStore = new UserStore(this);
        this.userDataStore = new UserDataStore(this);
        this.checkInStore = new CheckInStore(this);
    }
}

export const rootStore = new RootStore();
