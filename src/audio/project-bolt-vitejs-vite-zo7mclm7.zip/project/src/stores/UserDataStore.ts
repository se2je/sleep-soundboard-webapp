import {makeAutoObservable} from 'mobx';
import type {RootStore} from './RootStore';
import {fetchJson} from '@/api/fetchJson.ts';
import i18n from '@/i18n';

interface UserDataResponse {
    FUN: number;
    MTKN: number;
    checkin_streak: number;
    max_checkin_streak: number;
    karma?: number | null;
    keys?: number | null;
    tickets?: number | null;
    inventory?: InventoryData;

}

type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface InventoryData {
    cases: Record<string, number>; // { common_case: 1, epic_case: 2 }
    keys: Record<string, number>;  // { rare_key: 1, legendary_key: 0 }
    dogs: {
        id: string;
        type: string;
        rarity: Rarity;
        farm_rate: number;
        // остальные поля по желанию
    }[];
}

export class UserDataStore {
    currency = {tokens: 450000, gameCoins: 9200000};
    comboStreak = 0;
    maxComboStreak = 0;
    isLoading = false;
    karma = 0;
    keys = 0;
    tickets = 30;

    spinReward: any = null;

    inventory: InventoryData = {
        cases: {},
        keys: {},
        dogs: []
    };

    constructor(private root: RootStore) {
        makeAutoObservable(this);
    }

    async fetchUserData(userId: string) {
        this.isLoading = true;
        try {
            const data = await fetchJson<UserDataResponse>(
                `https://api.mysterytoken.org:8443/user/${userId}`
            );

            this.currency = {
                tokens: data.MTKN ?? 0,
                gameCoins: data.FUN ?? 0,
            };
            this.comboStreak = data.checkin_streak ?? 0;
            this.maxComboStreak = data.max_checkin_streak ?? 0;
            this.karma = data.karma ?? 0;
            this.keys = data.keys ?? 0;
            this.tickets = data.tickets ?? 0;
        } catch (error) {
            console.error('Ошибка получения данных пользователя:', error);
        } finally {
            this.isLoading = false;
        }
    }

    async checkIn(userId: string | null) {
        try {
            const data = await fetchJson<UserDataResponse>(
                `https://api.mysterytoken.org:8443/checkin/${userId}`,
                {method: 'POST'}
            );

            this.currency = {
                tokens: data.MTKN ?? 0,
                gameCoins: data.FUN ?? 0,
            };
            this.comboStreak = data.checkin_streak ?? 0;
            this.maxComboStreak = data.max_checkin_streak ?? 0;

            this.root.checkInStore.setIsCheckedIn();
        } catch (error) {
            console.error('Ошибка чек-ина:', error);
            this.root.uiStore.setErrorMessage(i18n.t('errors.checkIn'));
            this.root.checkInStore.setIsCheckedIn();
        }
    }

    async spendTicket(): Promise<boolean> {
        if (this.tickets < 3) {
            this.root.uiStore.setErrorMessage('Недостаточно билетиков 😢');
            return false;
        }

        try {
            const userId = this.root.userStore.userId;

            const response = await fetch(
                'https://api.mysterytoken.org:8443/user/spend-ticket',
                {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        user_id: userId,
                        amount: 3
                    })
                }
            );

            if (!response.ok) {
                this.root.uiStore.setErrorMessage('Ошибка при списании билетиков 😢');
                return false;
            }

            this.tickets -= 3;
            return true;
        } catch (err) {
            console.error('Ошибка списания билета:', err);
            this.root.uiStore.setErrorMessage('Что-то пошло не так 😢');
            return false;
        }
    }

    async spin(): Promise<any | null> {
        try {
            const userId = this.root.userStore.userId;

            const response = await fetch(
                `https://api.mysterytoken.org:8443/spin-wheel/${userId}`,
                {method: 'POST'}
            );

            if (!response.ok) {
                console.error('Ошибка API при рулетке');
                this.root.uiStore.setErrorMessage('Ошибка при получении награды 😢');
                return null;
            }

            const data = await response.json();
            const reward = data.reward;
            this.spinReward = reward;

            // 🟡 Моментальное обновление билетов
            if (reward.type === 'tickets' && typeof reward.amount === 'number') {
                this.tickets += reward.amount;
            }

            // 🔄 Общий апдейт данных (карма, FUN, MTKN, инвентарь)
            if (userId) {
                await this.fetchUserData(userId);
                await this.fetchInventory(userId);
            }

            return reward;
        } catch (err) {
            console.error('Ошибка запроса рулетки', err);
            this.root.uiStore.setErrorMessage('Не удалось прокрутить рулетку 😢');
            return null;
        }
    }

    async fetchInventory(userId: string) {
        try {
            const data = await fetchJson<UserDataResponse>(
                `https://api.mysterytoken.org:8443/user-inventory/${userId}`
            );

            const newInventory = data.inventory ?? {cases: {}, keys: {}, dogs: []};

            this.inventory.cases = newInventory.cases;
            this.inventory.keys = newInventory.keys;
            this.inventory.dogs = newInventory.dogs;

            this.karma = data.karma ?? 0;
            this.tickets = data.tickets ?? 0;
        } catch (err) {
            alert('Ошибка получения инвентаря:');
            this.root.uiStore.setErrorMessage('Не удалось загрузить инвентарь');
        }
    }

}
