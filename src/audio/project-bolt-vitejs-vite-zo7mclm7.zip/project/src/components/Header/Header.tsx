import {motion} from 'framer-motion';
import {CaretLeft} from '@phosphor-icons/react';
import {useNavigate} from 'react-router-dom';
import {observer} from 'mobx-react-lite';
import Currency from '@/components/Currency/Currency';
import ProfilePreview from '@/components/ProfilePreview/ProfilePreview';
import styles from './Header.module.scss';

interface HeaderProps {
    showCurrency?: boolean;
    showProfile?: boolean;
    showBack?: boolean;
    title?: string;
}

const Header = observer(({
    showCurrency = true,
    showProfile = true,
    showBack = false,
    title,
}: HeaderProps) => {
    const navigate = useNavigate();

    const handleBack = () => {
        navigate(-1);
    };

    return (
        <header className={styles.header}>
            <div className={styles.headerLeft}>
                {showBack && (
                    <motion.button
                        className={styles.backButton}
                        onClick={handleBack}
                        whileHover={{x: -5}}
                        whileTap={{scale: 0.95}}
                    >
                        <CaretLeft size={24} weight="bold"/>
                    </motion.button>
                )}
                {title && <h1 className={styles.title}>{title}</h1>}
                {showProfile && <ProfilePreview/>}
            </div>
            <div className={styles.headerRight}>
                {showCurrency && (
                    <div className={styles.currencyWrapper}>
                        <Currency/>
                    </div>
                )}
            </div>
        </header>
    );
});

export default Header;