import {motion} from 'framer-motion';
import {Link} from 'react-router-dom';
import {User, CheckCircle, Key, Ticket} from '@phosphor-icons/react';
import {observer} from 'mobx-react-lite';
import {rootStore} from '@/stores/RootStore';
import styles from './ProfilePreview.module.scss';
import {useTranslation} from "react-i18next";

const ProfilePreview = observer(() => {
    const {t} = useTranslation();

    return (
        <Link to="/dashboard" className={styles.profilePreview}>
            <motion.div
                className={styles.content}
                initial={{opacity: 0, y: 20}}
                animate={{opacity: 1, y: 0}}
            >
                <div className={styles.avatar}>
                    <div className={styles.avatarInner}>
                        {rootStore.userStore.avatarUrl ? (
                            <img src={rootStore.userStore.avatarUrl} alt="User Avatar"/>
                        ) : (
                            <User size={32} weight="duotone" className={styles.avatarIcon}/>
                        )}
                    </div>
                </div>

                <div className={styles.info}>
                    <h3 className={styles.username}>
                        {rootStore.userStore.username ? rootStore.userStore.username : 'Mystery User'}
                        <CheckCircle size={16} weight="fill" className={styles.verifiedBadge}/>
                    </h3>

                    <div className={styles.currencies}>
                        <div className={styles.currency}>
                            <Key size={16} weight="duotone" className={styles.icon}/>
                            <span>{rootStore.userDataStore.keys} {t('user.keys')}</span>
                        </div>
                        <div className={styles.currency}>
                            <Ticket size={16} weight="duotone" className={styles.icon}/>
                            <span>{rootStore.userDataStore.tickets} {t('user.tickets')}</span>
                        </div>
                    </div>
                </div>
            </motion.div>
        </Link>
    );
});

export default ProfilePreview;