import {useState} from 'react';
import {motion} from 'framer-motion';
import {Key, Ticket} from '@phosphor-icons/react';
import InfoPopup from '../InfoPopup/InfoPopup';
import styles from './Inventory.module.scss';
import {rootStore} from '@stores/RootStore.ts';
import {INVENTORY_ITEMS, DOG_IMAGES_BY_RARITY} from './inventoryItems';

const Inventory = () => {
    const [selectedItem, setSelectedItem] = useState<any | null>(null);
    const [activeTab, setActiveTab] = useState<'items' | 'dogs'>('items');
    const [rewardPopup, setRewardPopup] = useState<any | null>(null);
    const [isOpening, setIsOpening] = useState(false);

    const inventory = rootStore.userDataStore.inventory;
    const {keys, tickets} = rootStore.userDataStore;

    const handleItemAction = async (action: string, item: any) => {

        const isCase = typeof item?.key === 'string' && item.key.includes('_case');
        const isOpenAction = action === 'Открыть' || action === 'Open';

        if (isOpenAction && isCase) {

            const userId = rootStore.userStore.userId;
            if (!userId) {
                return;
            }

            try {
                setIsOpening(true);

                const caseType = item.rarity;
                const res = await fetch(`https://api.mysterytoken.org:8443/open-case/${userId}`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({case_type: caseType}),
                });


                if (!res.ok) {
                    throw new Error('Ошибка открытия кейса');
                }

                const data = await res.json();

                setRewardPopup(data.reward);
                await rootStore.userDataStore.fetchInventory(userId);
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
            } catch (err: any) {
            } finally {
                setIsOpening(false);
            }

        } else {
        }
    };

    const handleTabChange = (tab: 'items' | 'dogs') => {
        setSelectedItem(null);
        setActiveTab(tab);
    };

    const getItemMeta = (key: string) => INVENTORY_ITEMS.find((item) => item.key === key);

    // @ts-ignore
    return (
        <div className={styles.inventory}>
            <div className={styles.header}>
                <h2 className={styles.title}>Инвентарь</h2>
                <div className={styles.currencies}>
                    <div className={styles.currency}>
                        <Key size={24} weight="duotone" className={styles.icon}/>
                        <span className={styles.value}>{keys} Ключи</span>
                    </div>
                    <div className={styles.currency}>
                        <Ticket size={24} weight="duotone" className={styles.icon}/>
                        <span className={styles.value}>{tickets} Билеты</span>
                    </div>
                </div>
                <div className={styles.tabs}>
                    <button
                        className={`${styles.tab} ${activeTab === 'items' ? styles.active : ''}`}
                        onClick={() => handleTabChange('items')}
                    >
                        Инвентарь
                    </button>
                    <button
                        className={`${styles.tab} ${activeTab === 'dogs' ? styles.active : ''}`}
                        onClick={() => handleTabChange('dogs')}
                    >
                        Собаки
                    </button>
                </div>
            </div>

            <div className={styles.grid}>
                {activeTab === 'items' && Object.entries(inventory.cases)
                    .filter(([_, count]) => count > 0)
                    .map(([key, count], index) => {
                        const meta = getItemMeta(key);
                        return meta ? (
                            <motion.div
                                key={key + index}
                                className={styles.item}
                                onClick={() => setSelectedItem({...meta, amount: count})}
                                whileHover={{scale: 1.05}}
                                whileTap={{scale: 0.95}}
                            >
                                <img src={meta.image} alt={meta.name} className={styles.itemImage}/>
                                <div className={styles.itemName}>{meta.name}</div>
                                <div className={styles.itemAmount}>×{count}</div>
                            </motion.div>
                        ) : null;
                    })}

                {activeTab === 'items' && Object.entries(inventory.keys)
                    .filter(([_, count]) => count > 0)
                    .map(([key, count], index) => {
                        const meta = getItemMeta(key);
                        return meta ? (
                            <motion.div
                                key={key + index}
                                className={styles.item}
                                onClick={() => setSelectedItem({...meta, amount: count})}
                                whileHover={{scale: 1.05}}
                                whileTap={{scale: 0.95}}
                            >
                                <img src={meta.image} alt={meta.name} className={styles.itemImage}/>
                                <div className={styles.itemName}>{meta.name}</div>
                                <div className={styles.itemAmount}>×{count}</div>
                            </motion.div>
                        ) : null;
                    })}

                {activeTab === 'dogs' && inventory.dogs.map((dog, index) => (
                    <motion.div
                        key={dog.id || index}
                        className={styles.item}
                        onClick={() => setSelectedItem(dog)}
                        whileHover={{scale: 1.05}}
                        whileTap={{scale: 0.95}}
                    >
                        <img
                            src={DOG_IMAGES_BY_RARITY[dog.rarity]}
                            alt={dog.rarity}
                            className={styles.itemImage}
                        />
                        <div className={styles.itemName}>{dog.type}</div>
                        <div className={`${styles.itemRarity} ${styles[dog.rarity]}`}>
                            {dog.rarity.charAt(0).toUpperCase() + dog.rarity.slice(1)}
                        </div>
                    </motion.div>
                ))}
            </div>

            <InfoPopup
                isOpen={!!selectedItem}
                onClose={() => setSelectedItem(null)}
                title="Item Details"
            >
                {selectedItem && (
                    <div className={styles.itemDetails}>
                        {selectedItem.image ? (
                            <img src={selectedItem.image} alt={selectedItem.name} className={styles.itemImage}/>
                        ) : selectedItem.type === 'mutt' && selectedItem.rarity ? (
                            <img src={DOG_IMAGES_BY_RARITY[selectedItem.rarity as keyof typeof DOG_IMAGES_BY_RARITY]}
                                 alt="dog" className={styles.itemImage}/>
                        ) : null}                        <h3
                        className={styles.itemName}>{selectedItem.name || selectedItem.type}</h3>
                        {selectedItem.amount && (
                            <p className={styles.itemDescription}>×{selectedItem.amount}</p>
                        )}
                        {selectedItem.rarity && (
                            <div className={`${styles.itemRarity} ${styles[selectedItem.rarity]}`}>
                                {selectedItem.rarity.charAt(0).toUpperCase() + selectedItem.rarity.slice(1)}
                            </div>
                        )}
                        {selectedItem.description && (
                            <p className={styles.itemDescription}>{selectedItem.description}</p>
                        )}
                        {selectedItem.farm_rate && (
                            <p className={styles.itemDescription}>Farm rate: {selectedItem.farm_rate}</p>
                        )}
                        {selectedItem.actions && selectedItem.actions.length > 0 && (
                            <div className={styles.itemActions}>
                                {selectedItem.actions.map((action: string) => (
                                    <motion.button
                                        key={action}
                                        className={styles.actionButton}
                                        whileHover={{scale: 1.05}}
                                        whileTap={{scale: 0.95}}
                                        onClick={() => handleItemAction(action, selectedItem)}
                                    >
                                        {isOpening ? 'Открывается...' : action}
                                    </motion.button>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </InfoPopup>
            <InfoPopup
                isOpen={!!rewardPopup}
                onClose={() => setRewardPopup(null)}
                title="Вам выпал предмет!"
            >
                {rewardPopup && (
                    <motion.div
                        className={styles.itemDetails}
                        initial={{scale: 0.8, opacity: 0}}
                        animate={{scale: 1, opacity: 1}}
                        transition={{duration: 0.3}}
                    >
                        {rewardPopup.image_url ? (
                            <img
                                src={rewardPopup.image_url}
                                alt={rewardPopup.name}
                                className={styles.itemImage}
                            />
                        ) : rewardPopup.type === 'dog' && rewardPopup.rarity ? (
                            <img
                                src={DOG_IMAGES_BY_RARITY[rewardPopup.rarity as keyof typeof DOG_IMAGES_BY_RARITY]}
                                alt="dog"
                                className={styles.itemImage}
                            />
                        ) : null}

                        <h3 className={styles.itemName}>{rewardPopup.name}</h3>

                        {rewardPopup.rarity && (
                            <div
                                className={`${styles.itemRarity} ${styles[rewardPopup.rarity]}`}
                            >
                                {rewardPopup.rarity.charAt(0).toUpperCase() +
                                    rewardPopup.rarity.slice(1)}
                            </div>
                        )}

                        <p className={styles.itemDescription}>
                            {rewardPopup.type === 'dog'
                                ? 'Новая собака!'
                                : rewardPopup.type === 'tickets'
                                    ? `×${rewardPopup.data.amount} билетов`
                                    : rewardPopup.type === 'key'
                                        ? `Ключ (${rewardPopup.rarity})`
                                        : 'Неизвестная награда'}
                        </p>

                        <motion.button
                            className={styles.actionButton}
                            whileHover={{scale: 1.05}}
                            whileTap={{scale: 0.95}}
                            onClick={() => setRewardPopup(null)}
                        >
                            Забрать
                        </motion.button>
                    </motion.div>
                )}
            </InfoPopup>


        </div>
    );
};

export default Inventory;