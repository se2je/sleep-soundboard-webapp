import CASE_C from '@media/A2.png';
import CASE_R from '@media/B.png';
import CASE_E from '@media/C.png';
import CASE_L from '@media/D.png';

import KEY_C from '@media/A2_Key.png';
import KEY_R from '@media/B_Key.png';
import KEY_E from '@media/C2_Key.png';
import KEY_L from '@media/D_Key.png';

import DOG_C from '@media/dogs/mutt/common.png'
import DOG_R from '@media/dogs/mutt/rare.png'
import DOG_E from '@media/dogs/mutt/epic.png'
import DOG_L from '@media/dogs/mutt/legendary.png'

export type InventoryItemType = 'case' | 'key';
export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface InventoryItemMeta {
    key: string;
    type: InventoryItemType;
    rarity: Rarity;
    name: string;
    description: string;
    image: string;
    actions: string[];
}

export const INVENTORY_ITEMS: InventoryItemMeta[] = [
    {
        key: 'common_case',
        type: 'case',
        rarity: 'common',
        name: 'Basic Case',
        description: 'A mysterious box that contains a random NFT dog.',
        image: CASE_C,
        actions: ['Open']
    },
    {
        key: 'rare_case',
        type: 'case',
        rarity: 'rare',
        name: 'Cyber Case',
        description: 'A rare box with a higher chance of rare dogs.',
        image: CASE_R,
        actions: ['Open']
    },
    {
        key: 'epic_case',
        type: 'case',
        rarity: 'epic',
        name: 'Mystery Case',
        description: 'An epic case full of surprises and rare NFTs.',
        image: CASE_E,
        actions: ['Open']
    },
    {
        key: 'legendary_case',
        type: 'case',
        rarity: 'legendary',
        name: 'Jesus Case',
        description: 'A legendary case for legendary dogs.',
        image: CASE_L,
        actions: ['Open']
    },
    {
        key: 'common_key',
        type: 'key',
        rarity: 'common',
        name: 'Common Key',
        description: 'Opens common cases.',
        image: KEY_C,
        actions: []
    },
    {
        key: 'rare_key',
        type: 'key',
        rarity: 'rare',
        name: 'Rare Key',
        description: 'Opens rare cases.',
        image: KEY_R,
        actions: []
    },
    {
        key: 'epic_key',
        type: 'key',
        rarity: 'epic',
        name: 'Epic Key',
        description: 'Opens epic cases.',
        image: KEY_E,
        actions: []
    },
    {
        key: 'legendary_key',
        type: 'key',
        rarity: 'legendary',
        name: 'Legendary Key',
        description: 'Opens legendary cases.',
        image: KEY_L,
        actions: []
    }
];


export const DOG_IMAGES_BY_RARITY = {
    common: DOG_C,
    rare: DOG_R,
    epic: DOG_E,
    legendary: DOG_L,
};
