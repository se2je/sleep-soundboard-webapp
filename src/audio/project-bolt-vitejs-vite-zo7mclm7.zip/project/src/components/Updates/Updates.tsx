import {useKeenSlider} from "keen-slider/react"
import type {KeenSliderInstance} from "keen-slider"
import "keen-slider/keen-slider.min.css"
import {useState} from "react"
import styles from "./Updates.module.scss"
import banner1 from '@media/banner1.jpg'


const Updates = () => {
    const banners = [
        {
            image: banner1,
            caption: "Запуск токена 06.04.25",
            link: "https://t.me/nfine_coin"
        },

    ]

    const [currentSlide, setCurrentSlide] = useState(0)
    const [sliderInstance, setSliderInstance] = useState<KeenSliderInstance | null>(null)

    const [ref] = useKeenSlider<HTMLDivElement>(
        {
            loop: true,
            slides: {perView: 1},
            created: (slider) => {
                setSliderInstance(slider)
                setCurrentSlide(slider.track.details.rel)
            },
            slideChanged: (slider) => {
                setCurrentSlide(slider.track.details.rel)
            },
        },
        [
            (slider) => {
                let timeout: ReturnType<typeof setTimeout>
                let mouseOver = false

                const clearNextTimeout = () => clearTimeout(timeout)

                const nextTimeout = () => {
                    clearNextTimeout()
                    if (mouseOver) return
                    timeout = setTimeout(() => {
                        slider.next()
                    }, 10000)
                }

                slider.on("created", () => {
                    slider.container.addEventListener("mouseover", () => {
                        mouseOver = true
                        clearNextTimeout()
                    })
                    slider.container.addEventListener("mouseout", () => {
                        mouseOver = false
                        nextTimeout()
                    })
                    nextTimeout()
                })

                slider.on("dragStarted", clearNextTimeout)
                slider.on("animationEnded", nextTimeout)
                slider.on("updated", nextTimeout)
            },
        ]
    )

    return (
        <div className={styles.container}>
            <div ref={ref} className={`keen-slider ${styles.slider}`}>
                {banners.map((banner, index) => (
                    <a
                        key={index}
                        href={banner.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`keen-slider__slide ${styles.slide}`}
                    >
                        <img src={banner.image} alt={banner.caption}/>
                        <div className={styles.caption}>{banner.caption}</div>
                    </a>
                ))}
            </div>

            <div className={styles.dots}>
                {banners.map((_, idx) => (
                    <button
                        key={idx}
                        onClick={() => sliderInstance?.moveToIdx(idx)}
                        className={`${styles.dot} ${currentSlide === idx ? styles.active : ""}`}
                    />
                ))}
            </div>
        </div>
    )
}

export default Updates