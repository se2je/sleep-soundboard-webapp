import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import styles from './Card.module.scss';

interface CardProps {
  icon?: ReactNode;
  title: string;
  description: string;
}

const Card = ({ icon, title, description }: CardProps) => {
  return (
    <motion.div
      className={styles.card}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
    <div className={styles.cardWrapper}>
      {icon && <div className={styles.icon}>{icon}</div>}
      <h2 className={styles.title}>{title}</h2>
    </div>
      <p className={styles.description}>{description}</p>
    </motion.div>
  );
};

export default Card;