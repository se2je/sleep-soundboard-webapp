import {ReactNode} from 'react';
import {motion} from 'framer-motion';
import styles from './MenuItem.module.scss';

interface MenuItemProps {
    icon?: ReactNode;
    label: string;
    control: ReactNode;
    onClick?: () => void;
}

const MenuItem = ({icon, label, control, onClick}: MenuItemProps) => {


    return (
        <motion.div
            className={styles.menuItem}
            onClick={onClick}
            whileHover={{scale: 1.02}}
            whileTap={{scale: 0.98}}
            style={{cursor: onClick ? 'pointer' : 'default'}}
        >
            <div className={styles.label}>
                {icon && <span className={styles.icon}>{icon}</span>}
                {label}
            </div>
            <div className={styles.control}>
                {control}
            </div>
        </motion.div>
    );
};

export default MenuItem;