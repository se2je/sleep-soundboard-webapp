import {motion, AnimatePresence} from 'framer-motion';
import {X, SpeakerHigh, Translate} from '@phosphor-icons/react';
import {useTranslation} from 'react-i18next';
import MenuItem from './MenuItem';
import LanguageSwitcher from '../LanguageSwitcher/LanguageSwitcher';
import styles from './SettingsMenu.module.scss';

interface SettingsMenuProps {
    isOpen: boolean;
    onClose: () => void;
}

const SettingsMenu = ({isOpen, onClose}: SettingsMenuProps) => {
    const {i18n} = useTranslation();
    const {t} = useTranslation();

    const toggleLanguage = () => {
        const newLang = i18n.language === 'en' ? 'ru' : 'en';
        i18n.changeLanguage(newLang);
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    <motion.div
                        className={styles.overlay}
                        initial={{opacity: 0}}
                        animate={{opacity: 1}}
                        exit={{opacity: 0}}
                        onClick={onClose}
                    />
                    <motion.div
                        className={styles.settingsModal}
                        initial={{scale: 0.9, opacity: 0}}
                        animate={{scale: 1, opacity: 1}}
                        exit={{scale: 0.9, opacity: 0}}
                    >
                        <div className={styles.modalHeader}>
                            <h2 className={styles.modalTitle}>{t('settings.settings')}</h2>
                            <button
                                className={styles.closeButton}
                                onClick={onClose}
                            >
                                <X size={24} weight="bold"/>
                            </button>
                        </div>
                        <div className={styles.menuItems}>
                            <MenuItem
                                icon={<Translate size={20} weight="duotone"/>}
                                label={t('settings.language')}
                                control={<LanguageSwitcher disablePropagation={true}/>}
                                onClick={toggleLanguage}
                            />
                            <MenuItem
                                icon={<SpeakerHigh size={20} weight="duotone"/>}
                                label={t('settings.volume')}
                                control={
                                    <input
                                        type="range"
                                        min="0"
                                        max="100"
                                        defaultValue="50"
                                        style={{width: '100px'}}
                                    />
                                }
                            />
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
};

export default SettingsMenu;