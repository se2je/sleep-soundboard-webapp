// Обновлённый RoundCard.tsx — скрываем цену и изменение цены для next (upcoming) раунда

import { motion } from 'framer-motion';
import { Timer } from '@phosphor-icons/react';
import { useTranslation } from 'react-i18next';

import CountdownTimer from './CountdownTimer';
import ChartWidget from './ChartWidget';

import { Round } from '@/api/predictionGame';

import styles from './PredictionGame.module.scss';

interface RoundCardProps {
    round: Round;
    timeLeft: number;
    isCurrent: boolean;
    isPrevious: boolean;
    isLocked: boolean;
    showBetting?: boolean;
    canPlaceBet?: boolean;
    children?: React.ReactNode;
}

const RoundCard = ({
                       round,
                       timeLeft,
                       isCurrent,
                       isPrevious,
                       isLocked,
                       showBetting = false,
                       canPlaceBet = false,
                       children,
                   }: RoundCardProps) => {
    const { t } = useTranslation();

    const roundLabel = (() => {
        if (isCurrent) return t('games.prediction.currentRound');
        if (isPrevious) return t('games.prediction.previousRound');
        return t('games.prediction.nextRound');
    })();

    const formattedPrice =
        round.current_token_price !== null
            ? `$${round.current_token_price.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 6,
            })}`
            : '-';

    const priceChange = round.percentage_change;
    const isPositive = priceChange !== null && priceChange > 0;
    const isNegative = priceChange !== null && priceChange < 0;

    const formattedChange =
        priceChange !== null
            ? `${priceChange > 0 ? '+' : ''}${priceChange.toFixed(2)}%`
            : '-';

    const totalBets = round.bets_amount ?? 0;
    const prizePool = round.prize_pool ?? 0;

    const isNext = !isCurrent && !isPrevious;

    return (
        <motion.div
            key={round.round_id}
            className={`${styles.roundCard} 
                ${isCurrent ? styles.active : ''} 
                ${isPrevious ? styles.inactive : ''} 
                ${isLocked ? styles.locked : ''}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
        >
            <div className={styles.roundHeader}>
                <h2 className={styles.roundTitle}>{roundLabel}</h2>
                {isCurrent && (
                    <div className={styles.countdown}>
                        <Timer size={16} weight="bold" />
                        <CountdownTimer timeLeft={timeLeft} />
                    </div>
                )}
            </div>

            {/* Показываем цену и изменение только если НЕ next раунд */}
            {!isNext && (
                <div className={styles.priceInfo}>
                    <div className={styles.currentPrice}>{formattedPrice}</div>
                    <div
                        className={`${styles.priceChange} ${
                            isPositive
                                ? styles.positive
                                : isNegative
                                    ? styles.negative
                                    : ''
                        }`}
                    >
                        {formattedChange}
                    </div>
                </div>
            )}

            {isCurrent && (
                <div className={styles.chartContainer}>
                    <ChartWidget />
                </div>
            )}

            <div className={styles.totalBets}>Total Bets: {totalBets}</div>

            <div className={styles.prizePool}>
                <div className={styles.poolAmount}>{prizePool.toLocaleString()} NFUN</div>
                <div className={styles.poolLabel}>{t('games.prediction.prizePool')}</div>
            </div>

            {(canPlaceBet || showBetting) && children}
        </motion.div>
    );
};

export default RoundCard;