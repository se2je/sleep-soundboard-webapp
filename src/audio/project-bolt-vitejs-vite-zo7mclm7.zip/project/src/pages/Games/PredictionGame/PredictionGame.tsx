// Обновлённый PredictionGame.tsx — строгий рендеринг только previous/current/next

import { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { observer } from 'mobx-react-lite';
import { Trophy } from '@phosphor-icons/react';

import { rootStore } from '@/stores/RootStore';
import SettingsMenu from '@/components/Settings/SettingsMenu';
import GameInfo from './GameInfo';
import RoundCard from './RoundCard';
import BettingSection from './BettingSection';

import {
    fetchRounds,
    placeBet as apiPlaceBet,
    Prediction,
    Round,
} from '@/api/predictionGame';

import styles from './PredictionGame.module.scss';
import Header from "@components/Header/Header.tsx";

const MINIMUM_BET = 100;
const AUTO_UPDATE_INTERVAL = 10_000;

const PredictionGame = observer(() => {
    const { t } = useTranslation();
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [rounds, setRounds] = useState<Round[]>([]);
    const [showPreviousRound] = useState(false);
    const [timeLeft, setTimeLeft] = useState<number>(0);

    const userId = Number(rootStore?.userStore.userId);

    const loadRounds = useCallback(async () => {
        try {
            const data = await fetchRounds();
            setRounds(data);
        } catch (err) {
            rootStore.uiStore.setErrorMessage(t('errors.fetchFailed'));
        }
    }, [t]);

    useEffect(() => {
        loadRounds();
        const interval = setInterval(loadRounds, AUTO_UPDATE_INTERVAL);
        return () => clearInterval(interval);
    }, [loadRounds]);

    const currentRound = rounds.find((r) => r.status === 'active');

    useEffect(() => {
        if (!currentRound) return;

        const updateTimer = () => {
            const now = Date.now();
            const end = new Date(currentRound.end_time).getTime();
            const remaining = end - now;
            setTimeLeft(remaining > 0 ? remaining : 0);
        };

        updateTimer();
        const interval = setInterval(updateTimer, 1000);
        return () => clearInterval(interval);
    }, [currentRound]);

    const handleBet = async (amount: number, prediction: Prediction) => {
        const userCoins = rootStore.userDataStore.currency.gameCoins;

        if (!userId || isNaN(userId)) {
            rootStore.uiStore.setErrorMessage(t('errors.userNotLoggedIn'));
            return;
        }

        if (amount < MINIMUM_BET || amount > userCoins) {
            rootStore.uiStore.setErrorMessage(t('errors.invalidBet'));
            return;
        }

        try {
            await apiPlaceBet({ userId, amount, prediction });

            setRounds((prev) =>
                prev.map((round) =>
                    round.status === 'upcoming'
                        ? {
                            ...round,
                            bets_amount: round.bets_amount + 1,
                            prize_pool: round.prize_pool + amount,
                        }
                        : round
                )
            );
        } catch {
            rootStore.uiStore.setErrorMessage(t('errors.betFailed'));
        }
    };

    const now = Date.now();

    const previousRound = rounds.find((r) => r.status === 'completed');
    const nextRound = rounds.find((r) => r.status === 'upcoming');

    const canPlaceBet = (() => {
        if (!currentRound) return false;
        const start = new Date(currentRound.start_time).getTime();
        const end = new Date(currentRound.end_time).getTime();
        const duration = end - start;
        const elapsed = now - start;
        return elapsed / duration <= 0.25;
    })();

    return (
        <div className={styles.container}>
            <Header
                showBack={true}
                title= {t('tabs.gameTitles.prediction')}
                showProfile={false}
            />

            <GameInfo />

            <div className={styles.roundsContainer}>
                {showPreviousRound && previousRound && (
                    <RoundCard
                        key={`previous-${previousRound.round_id}`}
                        round={previousRound}
                        isPrevious
                        isCurrent={false}
                        isLocked={true}
                        timeLeft={0}
                    />
                )}

                {currentRound && (
                    <RoundCard
                        key={`current-${currentRound.round_id}`}
                        round={currentRound}
                        isCurrent
                        isPrevious={false}
                        isLocked={!canPlaceBet}
                        timeLeft={timeLeft}
                        canPlaceBet={canPlaceBet}
                    >
                        {canPlaceBet && (
                            <BettingSection
                                minimumBet={MINIMUM_BET}
                                onBet={handleBet}
                            />
                        )}
                    </RoundCard>
                )}

                {nextRound && (
                    <RoundCard
                        key={`next-${nextRound.round_id}`}
                        round={nextRound}
                        isPrevious={false}
                        isCurrent={false}
                        isLocked={false}
                        timeLeft={0}
                        showBetting
                    >
                        <BettingSection
                            minimumBet={MINIMUM_BET}
                            onBet={handleBet}
                        />
                    </RoundCard>
                )}
            </div>

            <div className={styles.userStats}>
                <div className={styles.stat}>
                    <div className={styles.statLabel}>{t('games.prediction.totalWinnings')}</div>
                    <div className={styles.statValue}>
                        <Trophy size={20} /> 12,500 NFUN
                    </div>
                </div>
            </div>

            <SettingsMenu
                isOpen={isSettingsOpen}
                onClose={() => setIsSettingsOpen(false)}
            />
        </div>
    );
});

export default PredictionGame;