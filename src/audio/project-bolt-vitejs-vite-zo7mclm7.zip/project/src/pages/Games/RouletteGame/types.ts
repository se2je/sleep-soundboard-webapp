// 🎨 Визуальное оформление призов для колеса
export interface PrizeStyle {
  backgroundColor: string;
  textColor: string;
  fontSize?: number;
}

export type RewardType =
    | 'case'
    | 'key'
    | 'keys_pack'
    | 'tickets'
    | 'mtkn_low'
    | 'mtkn_high'
    | 'ton'
    | 'fun';

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

// 🎁 Структура одного сектора колеса
export interface PrizeData {
  key: string;
  type: RewardType;
  rarity?: Rarity;
  option?: string;
  image?: {
    uri: string;
    sizeMultiplier?: number;
    landscape?: boolean;
  };
  style: PrizeStyle;
}

// 📦 Тип ответа с бэка — награда
export interface Prize {
  key: string;
  label: string;
  icon: string;
  type: RewardType;
  rarity?: Rarity;
}
