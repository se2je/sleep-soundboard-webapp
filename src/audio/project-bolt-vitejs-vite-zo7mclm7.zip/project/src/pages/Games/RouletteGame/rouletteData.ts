import {PrizeData} from './types';
import CASE from '@media/Case.png';
import KEY from '@media/Key.png';
import TICKET from '@media/Ticket.png';
import MONEY from '@media/Money_1.png';
import MONEY_1 from '@media/Money_2.png';
import DIAMOND from '@media/Diamond.png';
import COINS from '@media/Coins.png';
import KEY_1 from '@media/Key_icon.png';

import CASE_C from '@media/A2.png';
import CASE_R from '@media/B.png';
import CASE_E from '@media/C.png';
import CASE_L from '@media/D.png';

import KEY_C from '@media/A2_Key.png';
import KEY_R from '@media/B_Key.png';
import KEY_E from '@media/C2_Key.png';
import KEY_L from '@media/D_Key.png';

export const PRIZE_ICONS = {
    case: CASE,
    key: KEY,
    ticket: TICKET,
    money: MONEY,
    money_1: MONEY_1,
    diamond: DIAMOND,
    coins: COINS,
    key_1: KEY_1,
    case_c: CASE_C,
    case_r: CASE_R,
    case_e: CASE_E,
    case_l: CASE_L,
    key_c: KEY_C,
    key_r: KEY_R,
    key_e: KEY_E,
    key_l: KEY_L,

};

export const PRIZE_TEXTS: { [key: string]: string } = {
    case: 'Case!',
    key: 'Key!',
    ticket: 'Tickets!',
    money: 'NFINE!',
    money_1: 'NFINE!',
    diamond: 'TON!',
    coins: 'NFUN!',
    key_1: 'Keys!',
};

export const PRIZES: PrizeData[] = [
    // 🎁 Cases
    {
        key: 'case',
        type: 'case',
        rarity: 'common',
        image: {uri: PRIZE_ICONS.case_c, sizeMultiplier: 0.6},
        style: {backgroundColor: '#ab3c20', textColor: 'white'}
    },
    {
        key: 'case',
        type: 'case',
        rarity: 'rare',
        image: {uri: PRIZE_ICONS.case_r, sizeMultiplier: 0.6},
        style: {backgroundColor: '#264de4', textColor: 'white'}
    },
    {
        key: 'case',
        type: 'case',
        rarity: 'epic',
        image: {uri: PRIZE_ICONS.case_e, sizeMultiplier: 0.6},
        style: {backgroundColor: '#8e44ad', textColor: 'white'}
    },
    {
        key: 'case',
        type: 'case',
        rarity: 'legendary',
        image: {uri: PRIZE_ICONS.case_l, sizeMultiplier: 0.6},
        style: {backgroundColor: '#f59e0b', textColor: 'white'}
    },

    // 🗝 Keys
    {
        key: 'key',
        type: 'key',
        rarity: 'common',
        image: {uri: PRIZE_ICONS.key_c, sizeMultiplier: 0.6},
        style: {backgroundColor: '#024e70', textColor: 'white'}
    },
    {
        key: 'key',
        type: 'key',
        rarity: 'rare',
        image: {uri: PRIZE_ICONS.key_r, sizeMultiplier: 0.6},
        style: {backgroundColor: '#2662b6', textColor: 'white'}
    },
    {
        key: 'key',
        type: 'key',
        rarity: 'epic',
        image: {uri: PRIZE_ICONS.key_e, sizeMultiplier: 0.6},
        style: {backgroundColor: '#5b2c6f', textColor: 'white'}
    },
    {
        key: 'key',
        type: 'key',
        rarity: 'legendary',
        image: {uri: PRIZE_ICONS.key_l, sizeMultiplier: 0.6},
        style: {backgroundColor: '#c29200', textColor: 'white'}
    },

    // 🎁 Keys Pack (без rarity)
    {
        key: 'key_1',
        type: 'keys_pack',
        image: {uri: PRIZE_ICONS.key_1, sizeMultiplier: 0.6},
        style: {backgroundColor: '#0f4456', textColor: 'white'}
    },

    // 🎟 Tickets
    {
        key: 'ticket',
        type: 'tickets',
        image: {uri: PRIZE_ICONS.ticket, sizeMultiplier: 0.6},
        style: {backgroundColor: '#002f53', textColor: 'white'}
    },

    // 🪙 Валюта
    {
        key: 'money',
        type: 'mtkn_low',
        image: {uri: PRIZE_ICONS.money, sizeMultiplier: 0.6},
        style: {backgroundColor: '#004f60', textColor: 'white'}
    },
    {
        key: 'money_1',
        type: 'mtkn_high',
        image: {uri: PRIZE_ICONS.money_1, sizeMultiplier: 0.6},
        style: {backgroundColor: '#004054', textColor: 'white'}
    },
    {
        key: 'coins',
        type: 'fun',
        image: {uri: PRIZE_ICONS.coins, sizeMultiplier: 0.6},
        style: {backgroundColor: '#8f3a04', textColor: 'white'}
    },
    {
        key: 'diamond',
        type: 'ton',
        image: {uri: PRIZE_ICONS.diamond, sizeMultiplier: 0.6},
        style: {backgroundColor: '#cc700b', textColor: 'white'}
    },
];