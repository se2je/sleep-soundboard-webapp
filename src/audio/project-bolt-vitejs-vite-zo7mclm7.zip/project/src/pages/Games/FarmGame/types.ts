export interface FarmDog {
    id: string;
    type: string;
    name?: string;
    rarity: 'common' | 'rare' | 'epic' | 'legendary';
    farm_rate: number;
    max_farm_hours: number;
    worked_hours: number;
    farm_time?: string;
    farm_duration_hours?: number;
    rest_until?: string;
    retired?: boolean;
    tokenType?: string;
}