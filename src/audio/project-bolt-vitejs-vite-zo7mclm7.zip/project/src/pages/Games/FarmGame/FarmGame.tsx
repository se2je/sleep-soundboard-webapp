import { useState } from 'react';
import { motion } from 'framer-motion';
import { Dog, CaretDown, CaretUp } from '@phosphor-icons/react';
import { observer } from 'mobx-react-lite';
import Currency from '@/components/Currency/Currency';
import styles from './FarmGame.module.scss';
import { rootStore } from '@/stores/RootStore';
import { FarmDog } from './types.ts';
import {DOG_IMAGES_BY_RARITY} from './farmDogs.ts';
import Header from "@components/Header/Header.tsx";
import {useTranslation} from "react-i18next";

const RARITIES = {
    common: { color: '#8BC34A' },
    rare: { color: '#2196F3' },
    epic: { color: '#9C27B0' },
    legendary: { color: '#FFD700' }
};

const FarmGame = observer(() => {
    const userId = rootStore.userStore.userId;
    const dogs = rootStore.userDataStore.inventory.dogs as FarmDog[];
    const [expandedDogs, setExpandedDogs] = useState<string[]>([]);
    const { t } = useTranslation();

    const toggleDogStats = (dogId: string) => {
        setExpandedDogs(prev =>
            prev.includes(dogId)
                ? prev.filter(id => id !== dogId)
                : [...prev, dogId]
        );
    };

    const getFarmingProgress = (dog: FarmDog) => {
        if (!dog.farm_time || !dog.farm_duration_hours) return 0;
        const start = new Date(dog.farm_time).getTime();
        const end = start + dog.farm_duration_hours * 60 * 60 * 1000;
        const now = Date.now();
        return Math.min(100, Math.max(0, ((now - start) / (end - start)) * 100));
    };

    const formatTimeLeft = (dog: FarmDog) => {
        if (!dog.farm_time || !dog.farm_duration_hours) return '';
        const start = new Date(dog.farm_time).getTime();
        const end = start + dog.farm_duration_hours * 60 * 60 * 1000;
        const timeLeft = end - Date.now();
        if (timeLeft <= 0) return 'Готово';
        const hours = Math.floor(timeLeft / 3600000);
        const minutes = Math.floor((timeLeft % 3600000) / 60000);
        return `${hours}ч ${minutes}м`;
    };

    const startFarming = async (dogId: string) => {
        if (!userId) return;
        try {
            await fetch(`https://api.mysterytoken.org:8443/start-farm/${userId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ dog_id: dogId })
            });
            await rootStore.userDataStore.fetchInventory(userId);
        } catch (e) {
            console.error('Ошибка запуска фарма', e);
        }
    };

    const claimFarming = async (dogId: string) => {
        if (!userId) return;
        try {
            await fetch(`https://api.mysterytoken.org:8443/claim-farm/${userId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ dog_id: dogId })
            });
            await rootStore.userDataStore.fetchInventory(userId);
        } catch (e) {
            console.error('Ошибка сбора фарма', e);
        }
    };

    return (
        <div className={styles.container}>
            <Header
                showBack={true}
                title={t('tabs.gameTitles.nftDogs')}
                showProfile={false}
            />

            <div className={styles.farmContent}>
                <div className={styles.dogsCounter}>
                    <Dog size={24} weight="duotone" />
                    <span>Total Dogs: {dogs.length}</span>
                </div>

                <div className={styles.dogsGrid}>
                    {dogs.map(dog => (
                        <motion.div
                            key={dog.id}
                            className={styles.dogCard}
                            style={{
                                borderColor: RARITIES[dog.rarity].color,
                                boxShadow: `0 0 10px ${RARITIES[dog.rarity].color}33`
                            }}
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                        >
                            <div className={styles.dogHeader}>
                                <div className={styles.dogIcon}>
                                    <img
                                        src={DOG_IMAGES_BY_RARITY[dog.rarity]}
                                        alt={dog.rarity}
                                        className={styles.dogImage}
                                    />
                                </div>
                                <div className={styles.nameWrapper}>
                                    <h3 className={styles.dogName}>{dog.name || dog.type}</h3>
                                    <motion.button
                                        className={styles.expandButton}
                                        onClick={() => toggleDogStats(dog.id)}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                    >
                                        {expandedDogs.includes(dog.id) ? (
                                            <CaretUp size={20} weight="bold" />
                                        ) : (
                                            <CaretDown size={20} weight="bold" />
                                        )}
                                    </motion.button>
                                </div>
                            </div>

                            <div className={styles.dogInfo}>
                                <span className={styles.rarity} style={{ color: RARITIES[dog.rarity].color }}>
                                    {dog.rarity}
                                </span>
                                <span className={styles.tokenType}>{dog.tokenType || 'NFUN'}</span>
                            </div>

                            {expandedDogs.includes(dog.id) && (
                                <motion.div
                                    className={styles.statsBlock}
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                >
                                    <div className={styles.statRow}>
                                        <span>Фарм скорость:</span>
                                        <span>{dog.farm_rate.toFixed(2)} в час</span>
                                    </div>
                                    <div className={styles.statRow}>
                                        <span>Сессия:</span>
                                        <span>{dog.farm_duration_hours} ч</span>
                                    </div>
                                    <div className={styles.statRow}>
                                        <span>Отдых:</span>
                                        <span>{dog.rest_until ? 'До ' + new Date(dog.rest_until).toLocaleTimeString() : '—'}</span>
                                    </div>
                                    <div className={styles.statRow}>
                                        <span>Всего отработал:</span>
                                        <span>{dog.worked_hours} ч / {dog.max_farm_hours} ч</span>
                                    </div>
                                </motion.div>
                            )}

                            <motion.button
                                className={styles.farmButton}
                                onClick={() => {
                                    if (dog.farm_time) return;
                                    if (dog.rest_until && new Date(dog.rest_until) > new Date()) return;
                                    startFarming(dog.id);
                                }}
                                disabled={!!dog.farm_time || (!!dog.rest_until && new Date(dog.rest_until) > new Date())}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                <div
                                    className={styles.farmProgress}
                                    style={{ width: `${getFarmingProgress(dog)}%` }}
                                />
                                <div className={styles.farmButtonContent}>
                                    {dog.farm_time ? formatTimeLeft(dog) : 'Начать фарм'}
                                </div>
                            </motion.button>

                            {dog.farm_time && getFarmingProgress(dog) === 100 && (
                                <motion.button
                                    className={styles.claimButton}
                                    onClick={() => claimFarming(dog.id)}
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    Забрать награду
                                </motion.button>
                            )}
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
});

export default FarmGame;