import DOG_C from '@media/dogs/mutt/common.png'
import DOG_R from '@media/dogs/mutt/rare.png'
import DOG_E from '@media/dogs/mutt/epic.png'
import DOG_L from '@media/dogs/mutt/legendary.png'

export const DOG_IMAGES_BY_RARITY = {
    common: DOG_C,
    rare: DOG_R,
    epic: DOG_E,
    legendary: DOG_L,
};
