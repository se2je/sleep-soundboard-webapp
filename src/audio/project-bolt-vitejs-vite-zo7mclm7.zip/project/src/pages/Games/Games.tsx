import { motion } from 'framer-motion';
import {  ChartLineUp, CircleNotch, Dog } from '@phosphor-icons/react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import SettingsMenu from '@/components/Settings/SettingsMenu';
import styles from './Games.module.scss';
import {useTranslation} from "react-i18next";
import Header from "@components/Header/Header.tsx";


const Games = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const {t} = useTranslation();

  const GAMES = [
    {
      id: 'prediction',
      name: t('games.prediction.title'),
      description: t('games.prediction.description'),
      icon: <ChartLineUp size={32}  />,
      path: '/games/prediction',
      isPreview: false
    },
    {
      id: 'roulette',
      name: t('games.roulette.title'),
      description: t('games.roulette.description'),
      icon: <CircleNotch size={32}  />,
      path: '/games/roulette',
      isPreview: true
    },
    {
      id: 'farm',
      name: t('games.nftDogs.title'),
      description: t('games.nftDogs.description'),
      icon: <Dog size={32} />,
      path: '/games/farm',
      isPreview: true
    }
  ];

  return (
    <div className={styles.container}>
     <Header
         showBack={true}
         title= {t('tabs.games')}
         showProfile={false}
         showCurrency={false}
     />

      <div className={styles.gameGrid}>
        {GAMES.map((game) => (
          <Link 
            key={game.id} 
            to={game.path} 
            style={{ textDecoration: 'none' }}
          >
            <motion.div
              className={styles.gameCard}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {game.isPreview && (
                <div className={styles.previewBadge}>
                  ⏳
                </div>
              )}
              <div className={styles.gameIcon}>{game.icon}</div>
              <h2 className={styles.gameName}>{game.name}</h2>
              <p className={styles.gameDescription}>{game.description}</p>
            </motion.div>
          </Link>
        ))}
      </div>

      <SettingsMenu isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
};

export default Games;