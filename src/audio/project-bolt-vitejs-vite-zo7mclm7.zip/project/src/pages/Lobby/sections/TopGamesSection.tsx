import {motion} from 'framer-motion';
import {ChartLineUp, Dog} from '@phosphor-icons/react';
import {Link} from 'react-router-dom';
import {useTranslation} from 'react-i18next';
import styles from '../Lobby.module.scss';

const TopGamesSection = () => {
    const {t} = useTranslation();

    return (
        <motion.div
            className={styles.topGamesSection}
            initial={{opacity: 0, y: 20}}
            animate={{opacity: 1, y: 0}}
        >
            <div className={styles.gameCards}>
                <Link to="/games/prediction" style={{textDecoration: 'none', color: 'inherit'}}>
                    <div className={styles.gameCard}>
                        <ChartLineUp size={32} className={styles.icon}/>
                        <h2 className={styles.title}>{t('games.prediction.title')}</h2>
                    </div>
                </Link>
                <Link to="/games/farm" style={{textDecoration: 'none', color: 'inherit'}}>
                    <div className={styles.gameCard}>
                        <Dog size={32} className={styles.icon}/>
                        <h2 className={styles.title}>{t('games.prediction.title')}</h2>
                    </div>
                </Link>
            </div>
        </motion.div>
    );
};

export default TopGamesSection;