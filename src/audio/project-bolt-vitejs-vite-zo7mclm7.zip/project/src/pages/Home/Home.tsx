import {observer} from 'mobx-react-lite';
import {useTranslation} from 'react-i18next';
import {Brain, UsersThree, RocketLaunch} from '@phosphor-icons/react';
import {useEffect, useRef} from 'react';
import Button from '@/components/Button/Button';
import Card from '@/components/Card/Card';
import styles from './Home.module.scss';
import LanguageSwitcher from "@components/LanguageSwitcher/LanguageSwitcher.tsx";
import tg from '@media/tg.png';
import web from '@media/web.png';

import rocket_dog from '@media/rocketdog.png';

const Home = () => {
    const {t} = useTranslation();
    const starfieldRef = useRef<HTMLDivElement | null>(null); // Указываем тип

    useEffect(() => {
        if (!starfieldRef.current) return;

        const numStars = 40; // Количество звёзд
        for (let i = 0; i < numStars; i++) {
            const star = document.createElement("div");
            star.className = styles.star;

            // Случайное положение
            const x = Math.random() * 100;
            const y = Math.random() * 100;
            const size = Math.random() * 3 + 1;
            const opacity = Math.random() * 0.5 + 0.3;

            star.style.cssText = `
                left: ${x}%;
                top: ${y}%;
                width: ${size}px;
                height: ${size}px;
                opacity: ${opacity};
                animation-duration: ${Math.random() * 3 + 2}s; /* 2-5 секунд мерцания */
                animation-delay: ${Math.random() * 3}s; /* Разный старт мерцания */
            `;

            starfieldRef.current.appendChild(star);
        }
    }, []);

    return (
        <div className={styles.container}>
            <div className={styles.starfield} ref={starfieldRef}/>
            <div className={styles.links}>
                <a href="https://t.me/nfine_coin" target={'_blank'}> <img src={tg} alt="tg"/></a>
                <a href="https://nfine.org/" target={'_blank'}><img src={web} alt="web"/></a>

            </div>
            <div className={styles.switcherWrapper}>

                <LanguageSwitcher/>
            </div>
            <section className={styles.hero}>
                <div className={styles.mascot}>
                    <img
                        src={rocket_dog}
                        alt="Mascot"
                        className={styles.mascotImage}
                    />
                </div>
                <div className={styles.titleWrapper}>
                    {/*<GameController size={48} weight="duotone" className={styles.titleIcon}/>*/}
                    <h1 className={styles.title}>{t('home.title')}</h1>
                </div>
                {/*<p className={styles.description}>{t('home.description')}</p>*/}
                <a href='https://t.me/tokenmystery_bot' target={'_blank'}>
                    <Button icon={<RocketLaunch size={24} weight="duotone"/>}>
                        {t('home.checkIn')}
                    </Button>
                </a>
            </section>

            <section className={styles.features}>
                <Card
                    icon={<Brain size={32} weight="duotone"/>}
                    title={t('home.features.ai.title')}
                    description={t('home.features.ai.description')}
                />
                <Card
                    icon={<UsersThree size={32} weight="duotone"/>}
                    title={t('home.features.community.title')}
                    description={t('home.features.community.description')}
                />
            </section>
        </div>
    );
};

export default observer(Home);